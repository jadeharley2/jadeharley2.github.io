shader_type spatial;

render_mode  diffuse_burley, specular_schlick_ggx, blend_add, ambient_light_disabled;

uniform sampler2D texture_albedo : source_color, filter_nearest;
uniform sampler2D texture_emit : source_color, filter_nearest, hint_default_black;
uniform sampler2D texture_normal : hint_normal, filter_nearest;
uniform sampler2D texture_mask : hint_default_black, filter_nearest;

uniform vec4 albedo : source_color = vec4(1,1,1,1) ;
uniform vec4 emission : source_color = vec4(1,1,1,1) ;
uniform float alpha_scissor_threshold : hint_range(0.0, 1.0) = 0.5;

uniform vec3 ghost_center = vec3(0.0,1.2,0.0);
uniform float ghost_pow = 1.0;
uniform float ghost_intensity = 1.0;
uniform sampler2D ghost_gradient : hint_default_black, filter_linear,repeat_disable;

varying vec3 world_pos; 
varying vec3 world_norm;
void vertex() {
	world_pos = VERTEX;
	world_norm = vec3(1.0,0,0);// NORMAL;
	// Called for every vertex the material is visible on.
	
}

void fragment() {
	vec2 base_uv = UV;
	
	vec4 albedo_tex = texture(texture_albedo, base_uv);
	
	if(albedo_tex.a<alpha_scissor_threshold) discard;
	
	vec2 vpp = ( VIEW_MATRIX  * MODEL_MATRIX * vec4(ghost_center,1.0) ).xy;
	vec4 mask = texture(texture_mask,base_uv);
	vec4 emit = texture(texture_emit,base_uv);
	
	vec4 color0 = albedo_tex;
	float dghost = min(distance(VERTEX.xy,vpp)*ghost_pow,1.0);
	float viewdot =dot(NORMAL,vec3(0,0,1));
	float mpl =//1.0;// pow(viewdot,2.0)-0.5; //
		2.0*max(pow(viewdot,2.0)-0.5,pow(1.0-viewdot,4.0)*2.0);
	vec4 ghost_color_g = texture(ghost_gradient,vec2(dghost,0.5));//  mix(ghost_color,ghost_colorb,dghost);
	
	ALBEDO =vec3(0,0,0);// albedo.rgb * color0.rgb * ghost_color_g.rgb ;
	ALPHA = ghost_color_g.a;
	ROUGHNESS = mask.r;
	METALLIC = mask.b;
	SPECULAR = 0.5;

	vec3 nrmvec = (texture(texture_normal,base_uv).rgb-0.5)*2.0;
	nrmvec *=vec3(2,2,1);
	vec3 nrmclr = nrmvec*0.5+0.5;
	NORMAL_MAP = nrmclr;
	EMISSION = albedo.rgb * color0.rgb * ghost_color_g.rgb*mpl*ghost_intensity ;
}

//void light() {
//	// Called for every pixel for every light affecting the material.
//	// Uncomment to replace the default light processing function with this one.
//}
