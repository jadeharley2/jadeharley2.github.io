shader_type spatial;

render_mode blend_mix;

uniform vec4 albedo : source_color = vec4(1,1,1,1) ;
uniform sampler2D albedo_texture : source_color, filter_nearest;

varying vec4 vertex_color;

void vertex() {

	mat4 bmatrix;
	{
		vec4 vp = MODEL_MATRIX[0]*1.5;

		mat4 rotZ = mat4(
			vec4(cos(INSTANCE_CUSTOM.r),-sin(INSTANCE_CUSTOM.r),0,0),
			vec4(sin(INSTANCE_CUSTOM.r),cos(INSTANCE_CUSTOM.r),0,0),
			vec4(0,0,1,0),
			vec4(0,0,0,1));
		mat4 scl = mat4(
			vec4(vp.x,0,0,0),
			vec4(0,vp.x,0,0),
			vec4(0,0,vp.x,0),
			vec4(0,0,0,1));

		mat4 __wm = mat4(
			normalize(INV_VIEW_MATRIX[0]),
			normalize(INV_VIEW_MATRIX[1]),
			normalize(INV_VIEW_MATRIX[2]),
			MODEL_MATRIX[3]);
		bmatrix = VIEW_MATRIX  * __wm * rotZ * scl;
	}


	MODELVIEW_MATRIX = bmatrix;

	vertex_color = COLOR;
}

void fragment() {
	vec4 albedo_tex = texture(albedo_texture, UV) * vertex_color * albedo;
	ALBEDO = albedo_tex.rgb * albedo_tex.a;
	ALPHA = albedo_tex.a;
}

void light() {
	// Called for every pixel for every light affecting the material.
	// Uncomment to replace the default light processing function with this one.
	DIFFUSE_LIGHT += ATTENUATION * LIGHT_COLOR;
}
