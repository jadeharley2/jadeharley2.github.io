shader_type spatial;
render_mode unshaded;

uniform vec3 Color : source_color = vec3(1,1,1);


void fragment() {
	ALBEDO = Color;
}
