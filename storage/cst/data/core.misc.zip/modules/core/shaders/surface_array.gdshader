shader_type spatial;

render_mode depth_prepass_alpha , diffuse_burley, specular_schlick_ggx;

uniform bool MASK_MODE = false;

uniform vec4 albedo : source_color = vec4(1,1,1,1) ;
uniform sampler2DArray texture_albedo : source_color, filter_nearest_mipmap_anisotropic;
uniform sampler2DArray texture_emit : source_color, filter_nearest_mipmap_anisotropic, hint_default_black;
uniform sampler2DArray texture_normal : hint_normal, filter_nearest_mipmap_anisotropic;
uniform sampler2DArray texture_mask : hint_default_white, filter_nearest_mipmap_anisotropic;

uniform sampler2DArray mask_array : source_color, filter_nearest_mipmap_anisotropic;
uniform sampler3D noise: source_color, filter_nearest,hint_default_black;

uniform float specular: hint_range(0,1) = 0.5;
uniform float metallic: hint_range(-1,1) = 0.0;
uniform float roughness : hint_range(-1,1) = 1.0;
uniform float alpha_scissor_threshold : hint_range(0.0, 1.0) = 0.5;

//global uniform vec3 global_bend_origin;
//global uniform float global_bend_power = 0.0001;

global uniform vec4 clip_plane0;

vec3 rgb2hsv(vec3 c) {
    vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));

    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}

vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

vec3 RotateVector(vec3 point, vec3 axis, float angle)
{
    vec3 vxp = cross(axis, point);
    vec3 vxvxp = cross(axis, vxp);
    return point + sin(angle) * vxp + (1.0 - cos(angle)) * vxvxp;
}

varying vec3 local_pos;
varying vec3 world_pos;
varying vec3 vertex_color;

//varying vec2 blend ;
varying vec3 base_uv ;
varying vec3 base_uv2;

void vertex()
{
	if(!IN_SHADOW_PASS)
	{
		local_pos = VERTEX.xyz;
		world_pos = ( MODEL_MATRIX * vec4( VERTEX, 1.0 ) ).xyz;
		vertex_color = COLOR.rgb;
		//float dist = distance(world_pos,global_bend_origin);
		//vec2 offsets = (world_pos-global_bend_origin).xz;
		//vec3 origin = vec3(global_bend_origin.x,0,global_bend_origin.z);
		//VERTEX = RotateVector(RotateVector(VERTEX+ NODE_POSITION_WORLD-origin,  vec3(1,0,0),offsets.y*global_bend_power),vec3(0,0,-1),offsets.x*global_bend_power)+origin-NODE_POSITION_WORLD;
		//NORMAL = RotateVector(RotateVector(NORMAL, vec3(1,0,0),offsets.y*global_bend_power ),vec3(0,0,-1),offsets.x*global_bend_power);

		vec2 indexes = floor(UV2+vec2(0.001,0.001));
		base_uv = vec3(UV,indexes.x);
		if(MASK_MODE){
			base_uv2 = base_uv;
		}else{
			base_uv2 = vec3(UV,indexes.x+indexes.y);
		}
		//blend = UV2 - indexes;
	}

}

void fragment() {
	if(!IN_SHADOW_PASS)
	{
		vec4 VERTEX_WORLD = INV_VIEW_MATRIX * vec4(VERTEX, 1.0);
		if(dot(VERTEX_WORLD.xyz,clip_plane0.xyz)<clip_plane0.w){
			discard;
		}

		vec4 noise_tex = texture( noise, local_pos.xyz/32.0-0.000001);
		
		vec3 tex_uv = mix(base_uv,base_uv2,noise_tex.x);
		//vec2 blend2  = blend ;// vec2(mod(UV.x,1),0)  ;//test

		vec4 albedo_tex = texture( texture_albedo, tex_uv);
		//vec4 albedo_tex2 = texture( texture_albedo, base_uv2);

		vec4 cliptex =  texture( mask_array, vec3(UV,UV2.y));
		float clipmask = cliptex.r;

		//vec3 hsv = rgb2hsv(albedo_tex.rgb);
		//hsv.x+=TIME;
		//albedo_tex.rgb = hsv2rgb(hsv);
		vec4 color0 =   albedo_tex;
		//vec4 color0 =   mix(albedo_tex,albedo_tex2,blend2.x);

		//ALBEDO = mat3(INV_VIEW_MATRIX) * (BINORMAL ).xyz;
		//ALBEDO = vec3(mod(UV.x/16.0,1),mod(UV.y/16.0,1),0);//
		ALBEDO = albedo.rgb * color0.rgb * vertex_color * COLOR.rgb;// * cliptex.g ;//hsv2rgb(color0);

		vec4 mask_tex = texture( texture_mask, tex_uv);
		//vec4 mask_tex2 = texture( texture_mask, base_uv2);

		vec4 mask = mask_tex;
		//vec4 mask =  mix(mask_tex,mask_tex2,blend2.x);
		ROUGHNESS = mask.r + roughness;// * roughness_tex
		METALLIC = mask.b  + metallic;// * metallic_tex;
		SPECULAR = specular;


		vec4 normal_tex = texture( texture_normal, tex_uv);
		//vec4 normal_tex2 = texture( texture_normal, base_uv2);


		vec3 nrmvec = (normal_tex.rgb-0.5)*2.0;
		//vec3 nrmvec = (mix(normal_tex.rgb,normal_tex2.rgb,blend2.x)-0.5)*2.0;
		nrmvec *=vec3(2,2,1);
		vec3 nrmclr = nrmvec*0.5+0.5;
		NORMAL_MAP = nrmclr;
		EMISSION = texture( texture_emit,base_uv).rgb*2.0*vertex_color;
		//vec3 transmission_tex = texture(texture_transmission, base_uv).rgb;
		//TRANSMISSION = (transmission.rgb + transmission_tex);
		ALPHA = albedo.a * albedo_tex.a * clipmask;
		ALPHA_SCISSOR_THRESHOLD =  alpha_scissor_threshold;
	
		//ALBEDO = vec3(tex_uv.xy/16.0,0.0);
	}
}


float DistributionGGX(float cos_theta_m, float alpha)
{
	float alpha2 = alpha * alpha;
	float d = 1.0 + (alpha2 - 1.0) * cos_theta_m * cos_theta_m;
	return alpha2 / (PI * d * d);
}

float GeometryGGX(float NdotL, float NdotV, float alpha)
{
	return 0.5 / mix(2.0 * NdotL * NdotV, NdotL + NdotV, alpha);
}

vec3 SchlickBaseReflectivity(float metallic2, float specular2, vec3 albedo2)
{
	float dielectric = 0.04 * specular2 * specular2;
	return mix(vec3(dielectric), albedo2, vec3(metallic2));
}
	
float SchlickFresnel(float u)
{
	float m = 1.0 - u;
	float m2 = m * m;
	return m2 * m2 * m;
}

/*
void light()
{
	float rough = ROUGHNESS;
	vec3 alb = ALBEDO;
	if(SPECULAR_AMOUNT>=16.0&&ATTENUATION>0.001)//LIGHT_COLOR.x<0.01&&LIGHT_COLOR.z<0.01&&LIGHT_COLOR.y<0.01&& ATTENUATION>0.001){
	{
		rough = 0.1;
		alb = vec3(1,0,0);
	}
	// Calculate some vectors.
	vec3 lightColor = LIGHT_COLOR / PI;
	
	vec3 half = normalize(VIEW + LIGHT);
	
	float NdotL = max(dot(NORMAL, LIGHT), 0.0);
	float NdotV = max(dot(NORMAL, VIEW), 0.0);
	float NdotH = max(dot(NORMAL, half), 0.0);
	float LdotH = max(dot(LIGHT, half), 0.0);
	
	// Diffuse light (Lambert).
	DIFFUSE_LIGHT += clamp(dot(NORMAL, LIGHT), 0.0, 1.0) * ATTENUATION * lightColor;
	
	// Specular light (Schlick-GGX).
	float ggxAlpha = rough * rough;
	float D = DistributionGGX(NdotH, ggxAlpha);
	float G = GeometryGGX(NdotL, NdotV, ggxAlpha);
	
	vec3 f0 = SchlickBaseReflectivity(METALLIC, SPECULAR_AMOUNT, alb);
	float LdotH5 = SchlickFresnel(LdotH);
	float f90 = clamp(50.0 * f0.g, 0.0, 1.0);
	vec3 F = f0 + (f90 - f0) * LdotH5;
	
	vec3 specularBRDF = max(NdotL * D * G * F, 0.0);
	SPECULAR_LIGHT += specularBRDF * LIGHT_COLOR * ATTENUATION;
	
}*/
