shader_type spatial;
uniform bool use_srgb = false;
uniform samplerCube cubemap : filter_linear, source_color;
void vertex() {
	// Called for every vertex the material is visible on.
}

void fragment() {
	ALBEDO = vec3(0,0,0);
	vec3 clr = texture(cubemap,(vec4(NORMAL,1) * VIEW_MATRIX).xyz *vec3(1,1,-1)).rgb;
	if(use_srgb){
		EMISSION =	vec3(pow(clr.r, 2.2f),pow(clr.g, 2.2f),pow(clr.b, 2.2f));
	}
	else{
		EMISSION = clr;
	}
}

//void light() {
	// Called for every pixel for every light affecting the material.
	// Uncomment to replace the default light processing function with this one.
//}
