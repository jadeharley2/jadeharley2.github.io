shader_type spatial;

render_mode depth_prepass_alpha , diffuse_burley, specular_schlick_ggx;

uniform vec4 albedo : source_color = vec4(1,1,1,1) ; 
uniform sampler2D albedo_texture : source_color, repeat_disable, filter_nearest;
uniform sampler2D emit_texture : source_color, repeat_disable, filter_nearest, hint_default_black;
uniform sampler2D texture_normal : hint_normal, repeat_disable, filter_nearest;
uniform float specular: hint_range(0,1) = 0.5;
uniform float metallic: hint_range(-1,1) = 0.0;
uniform float roughness : hint_range(-1,1) = 1.0;
uniform float alpha_scissor_threshold : hint_range(0.0, 1.0); 
uniform sampler2D texture_mask : hint_default_black, repeat_disable, filter_nearest;

uniform vec2 position = vec2(0,0) ; 
uniform vec2 scale = vec2(1,1) ; 

global uniform vec4 clip_plane0;

void vertex() {
	// Called for every vertex the material is visible on.
}

void fragment() {
	vec4 VERTEX_WORLD = INV_VIEW_MATRIX * vec4(VERTEX, 1.0);
	if(dot(VERTEX_WORLD.xyz,clip_plane0.xyz)<clip_plane0.w){ 
		discard;
	}
	
	vec2 base_uv = (UV-position-vec2(0.5,0.5))/scale+vec2(0.5,0.5);
	vec4 albedo_tex = texture(albedo_texture, base_uv); 
	
	vec4 color0 = albedo_tex;// mix(albedo_tex,albedo2_tex,noise_tex);//rgb2hsv( albedo_tex.rgb);
	//color0.y =color0.y+(noise_tex.r-0.5)*noise_shift_mul;
	ALBEDO =  albedo.rgb *color0.rgb;//hsv2rgb(color0);
	vec4 mask = texture(texture_mask,base_uv);
	ROUGHNESS = mask.r + roughness;// * roughness_tex
	METALLIC = mask.b  + metallic;// * metallic_tex; 
	SPECULAR = specular; 
	
	vec3 nrmvec = (texture(texture_normal,base_uv).rgb-0.5)*2.0;
	nrmvec *=vec3(2,2,1);
	vec3 nrmclr = nrmvec*0.5+0.5;
	NORMAL_MAP = nrmclr;
	EMISSION = texture(emit_texture,base_uv).rgb*10.0;
	//vec3 transmission_tex = texture(texture_transmission, base_uv).rgb;
	//TRANSMISSION = (transmission.rgb + transmission_tex);
	ALPHA = albedo.a * albedo_tex.a;
	ALPHA_SCISSOR_THRESHOLD = alpha_scissor_threshold;
}

//void light() {
	// Called for every pixel for every light affecting the material.
	// Uncomment to replace the default light processing function with this one.
//}
