shader_type spatial;
render_mode diffuse_burley, specular_schlick_ggx;

uniform sampler2D albedo_texture : source_color, filter_linear_mipmap_anisotropic, repeat_disable;
uniform float lod_distance : hint_range(0.0, 1000.0) = 60;

uniform sampler2D detail_texture : source_color, filter_linear_mipmap_anisotropic, hint_default_white;

uniform sampler3D lod_mask : source_color, filter_nearest, repeat_disable, hint_default_transparent;
global uniform vec3 lod_size = vec3(64,64,64);
global uniform vec3 lod_offset; 


uniform vec3 water_color: source_color;
uniform vec3 coast_color: source_color;
uniform vec3 side_color: source_color;

global uniform vec3 global_bend_origin;
global uniform float global_bend_power = 0.00005;

vec3 RotateVector(vec3 point, vec3 axis, float angle)
{
    vec3 vxp = cross(axis, point);
    vec3 vxvxp = cross(axis, vxp);
    return point + sin(angle) * vxp + (1.0 - cos(angle)) * vxvxp;
}
vec3 RotateVectorAroundPivot(vec3 point, vec3 pivot, vec3 axis, float angle)
{
    return pivot + RotateVector(point - pivot, axis, angle);
}

varying float vdist;
varying float height;
varying vec3 wpos;
void vertex(){
	vec3 world_pos = VERTEX + NODE_POSITION_WORLD;
	vec3 world_camera = (INV_VIEW_MATRIX * vec4(0.0, 0.0, 0.0, 1.0)).xyz;
	wpos = world_pos;

	float dist = distance(world_pos,global_bend_origin);
	vec2 offsets = (world_pos-global_bend_origin).xz;
	vec3 origin = vec3(global_bend_origin.x,0,global_bend_origin.z);
	height = VERTEX.y;

	VERTEX = RotateVector(RotateVector(VERTEX+ NODE_POSITION_WORLD-origin,  vec3(1,0,0),offsets.y*global_bend_power),vec3(0,0,-1),offsets.x*global_bend_power)+origin-NODE_POSITION_WORLD;
	NORMAL = RotateVector(RotateVector(NORMAL, vec3(1,0,0),offsets.y*global_bend_power ),vec3(0,0,-1),offsets.x*global_bend_power);



	//float lod_shift = min(dist-lod_distance*2.0,0)*0.1;
	//VERTEX = vec3(0,lod_shift,0) + VERTEX;
	vdist = dist;
}

void fragment() {
	vec4 albedo_tex = texture(albedo_texture, UV);

	vec4 albedo_detail_tex = texture(detail_texture, UV*512.0);

	//vec2 wp = (wpos).xz;
	vec3 wp = (wpos).xzy;
	float mask = texture(lod_mask, wp/(16.0*lod_size)+0.5+(lod_offset)/lod_size).r;

	if(mask>0.5){
		discard;
	}

	ALBEDO = albedo_tex.rgb * albedo_detail_tex.rgb*4.0;
	SPECULAR = 0.0;//
	if(height<0.2){
		ALBEDO = water_color;
		SPECULAR = 1.0;//
		ROUGHNESS = 0.2;
	}
	else if(height<2.0){
		ALBEDO = coast_color;
	}

	if(vdist<lod_distance){
		//discard;
	}
	//vec4 prjd = PROJECTION_MATRIX * vec4(VERTEX*vec3(1,1,5),1.0);
	//DEPTH = (prjd.z / prjd.w) ; //* 0.9999
}
