shader_type spatial;
render_mode unshaded;//, blend_add;

uniform sampler2D albedo_texture : source_color;
uniform vec3 color : source_color = vec3(0.1,0.4,1.0);
uniform float speed : hint_range(0.0, 10.0, 0.01) = 1;
uniform float phase : hint_range(-2.0, 2.0, 0.01) = 0.0;

void vertex() {
	// Called for every vertex the material is visible on.
}

void fragment() {
	vec2 basesuv = UV*vec2(2.0,2.0/max(speed,1));
	float scaled_time = min(speed,1)*TIME;
	vec3 px = texture(albedo_texture,basesuv+vec2(0.0,scaled_time)).rgb
	+texture(albedo_texture,basesuv+vec2(0.5,scaled_time*0.5)).rgb*0.5
	+texture(albedo_texture,basesuv+vec2(0.25,scaled_time*0.2)).rgb*0.25;
	px*=px*2.0;

	vec3 world_normal = normalize(NORMAL * mat3( VIEW_MATRIX)* mat3( MODEL_MATRIX));
	float dotx = world_normal.y*0.2  + pow(world_normal.y,2.0)*0.4 + pow(world_normal.y,5.0)*4.0;

	float edge =0.0;
	if(phase<0.0){
		edge = (dotx*-0.2+px.x*4.0+1.0) + (phase);
	}
	else{
		edge = (dotx*0.2+px.x*4.0+1.0) - phase;
	}
	if(edge<0.0) discard;
	px+=color*max(0.0,0.004-edge)*2000.0;

	px+=dotx*color*1.0;
	ALBEDO = px * speed;
}
