shader_type spatial;

render_mode unshaded, blend_add;

uniform float brightness = 1.0;
uniform vec4 tint : source_color = vec4(1,1,1,1) ;
uniform sampler2D emit_texture : source_color, filter_nearest, hint_default_black;


global uniform vec4 clip_plane0;


void fragment() {
	vec4 VERTEX_WORLD = INV_VIEW_MATRIX * vec4(VERTEX, 1.0);
	if(dot(VERTEX_WORLD.xyz,clip_plane0.xyz)<clip_plane0.w){
		discard;
	}

	ALBEDO = texture(emit_texture,UV).rgb*tint.rgb*COLOR.rgb*brightness;
}
