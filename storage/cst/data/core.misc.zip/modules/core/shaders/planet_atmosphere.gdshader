shader_type spatial;

render_mode depth_test_disabled, unshaded;

varying float pvalue;
varying vec3 wpos;
varying vec3 vdir;

uniform vec3 _PlanetCenter = vec3(0,0,0);
uniform float _PlanetRadius = 30;
uniform float _AtmosphereRadius = 40;
 
float length_sq(vec3 v) {
	return (v.x * v.x + v.y * v.y + v.z * v.z);
}
bool sphere_intesect(vec3 ro, vec3 rd, out float t0, out float t1 ) {
	float t = dot(_PlanetCenter - ro, rd);
	vec3 pM = ro + rd * t;
	float height = length_sq(pM - _PlanetCenter);
	if (height > _AtmosphereRadius * _AtmosphereRadius) return false;
	float x = sqrt(_AtmosphereRadius * _AtmosphereRadius - height);
	t0 = (t - x < 0.0) ? 0.0 : t - x;
	if ( height < _PlanetRadius * _PlanetRadius && t > 0.0) {
		float x = sqrt(_PlanetRadius * _PlanetRadius - height);
		t1 = t - x;
	}
	else {
		t1 = t + x;
	}
	return true;
}

void vertex() {
	mat4 n_out2p0;
// GetBillboardMatrix:2
	{	
		vec4 dir = vec4(MODEL_MATRIX[3].xyz - CAMERA_POSITION_WORLD,0);
		
		float a,b;
		bool r =sphere_intesect(CAMERA_POSITION_WORLD.xyz,dir.xyz,a,b);
		pvalue = a;//  (1.0/(2.0*length(dir)));  

		
		vec4 up = vec4(0,1,0,0);
		vec4 right = vec4(cross(dir.xyz,up.xyz),0);
		up = vec4(cross(dir.xyz,-right.xyz),0);
		mat4 __wm = mat4(
			normalize(right),
			normalize(up), 
			normalize(dir), 
			MODEL_MATRIX[3]);
		//__wm = __wm * mat4(
		//	vec4(cos(INSTANCE_CUSTOM.x), -sin(INSTANCE_CUSTOM.x), 0.0, 0.0), 
		//	vec4(sin(INSTANCE_CUSTOM.x), cos(INSTANCE_CUSTOM.x), 0.0, 0.0), 
		//	vec4(0.0, 0.0, 1.0, 0.0), vec4(0.0, 0.0, 0.0, 1.0));
		__wm = __wm * mat4(
			vec4(length(MODEL_MATRIX[0].xyz), 0.0, 0.0, 0.0), 
			vec4(0.0, length(MODEL_MATRIX[1].xyz), 0.0, 0.0), 
			vec4(0.0, 0.0, length(MODEL_MATRIX[2].xyz), 0.0), 
			vec4(0.0, 0.0, 0.0, 1.0));
			
		wpos = (__wm * vec4(VERTEX, 1.0)).xyz;
		vdir = wpos - CAMERA_POSITION_WORLD;
		n_out2p0 = VIEW_MATRIX * __wm;
	}


// Output:0
	MODELVIEW_MATRIX = n_out2p0;
	

}
void fragment() { 
	 
	ALBEDO =vec3(0,0,0);// step(length(UV-vec2(0.5,0.5)),a)*vec3(1,0,0);
	// Called for every pixel the material is visible on.
	float a,b;
	if(sphere_intesect(wpos,vdir,a,b)){
		ALBEDO = vec3(a,b,0);
	}
	ALPHA=0.5;
}

//void light() {
//	// Called for every pixel for every light affecting the material.
//	// Uncomment to replace the default light processing function with this one.
//}
