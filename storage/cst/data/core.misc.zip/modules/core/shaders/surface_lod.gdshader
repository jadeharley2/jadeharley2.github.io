shader_type spatial;

render_mode depth_draw_opaque , diffuse_burley, specular_schlick_ggx;

uniform vec4 albedo : source_color = vec4(1,1,1,1) ;
uniform float specular: hint_range(0,1) = 0;
uniform float metallic: hint_range(-1,1) = 0.0;
uniform float roughness : hint_range(-1,1) = 1.0;

global uniform vec4 clip_plane0;

varying vec4 vertex_color;
void vertex()
{
	VERTEX.xyz = VERTEX.xyz-NORMAL.xyz*0.01;
	vertex_color = COLOR.rgba;
}

void fragment() {
	vec4 VERTEX_WORLD = INV_VIEW_MATRIX * vec4(VERTEX, 1.0);
	if(dot(VERTEX_WORLD.xyz,clip_plane0.xyz)<clip_plane0.w){
		discard;
	}

	ALBEDO = vertex_color.rgb* COLOR.rgb;//hsv2rgb(color0);
	ROUGHNESS = roughness;//*vertex_color.a;// * roughness_tex
	METALLIC = metallic;// * metallic_tex;
	SPECULAR = 0.0;// 1.0-vertex_color.a;
}
