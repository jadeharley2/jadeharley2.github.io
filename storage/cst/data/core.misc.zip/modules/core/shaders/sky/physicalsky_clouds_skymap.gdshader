// Cloud Raymarching based on: A. Schneider. “The Real-Time Volumetric Cloudscapes Of Horizon: Zero Dawn”. ACM SIGGRAPH. Los Angeles, CA: ACM SIGGRAPH, 2015. Web. 26 Aug. 2015.
 
shader_type sky;

#if CURRENT_RENDERER != RENDERER_COMPATIBILITY  
render_mode use_half_res_pass, use_quarter_res_pass;
#endif 

uniform sampler3D bluenoise : filter_linear_mipmap, repeat_enable;

uniform sampler3D worlnoise : filter_linear_mipmap, repeat_enable;
uniform sampler3D perlworlnoise : filter_linear_mipmap, repeat_enable;
uniform sampler2D weathermap : filter_linear_mipmap, repeat_enable;
uniform sampler2D global_weathermap : filter_linear_mipmap, repeat_enable;

uniform samplerCube cubemap : filter_linear_mipmap;
uniform float cubemap_mul :hint_range(0.0, 20.0) = 1.0;

uniform vec3 atmosphere_sun_color :source_color = vec3(1.0);
uniform vec3 atmosphere_ambient_color :source_color = vec3(1.0);
uniform vec3 atmosphere_ground_color :source_color = vec3(1.0);
uniform vec4 ground_color : source_color = vec4(1.0); 

uniform vec2 wind_direction = vec2(1, 0);
uniform float wind_speed :hint_range(0.0, 20.0) = 1.0;
uniform float _density : hint_range(0.01, 0.2) = 0.05;
uniform float cloud_coverage :hint_range(0.0, 1.0) = 0.25;
uniform float _time_offset : hint_range(0.0, 1000.0, 0.5) = 0.0;

// Approximately earth sizes
uniform float planet_radius_km=6000;
uniform float cloud_bottom_height=1500;
uniform float cloud_top_height=4000;

uniform float under_cutoff_distance=24000;
uniform float incloud_cutoff_distance=10000;

#define g_radius (planet_radius_km*1000.0)

#define sky_b_radius (planet_radius_km*1000.0+cloud_bottom_height)
#define sky_t_radius (planet_radius_km*1000.0+cloud_top_height)
#define t_dist (cloud_top_height-cloud_bottom_height)

   

uniform float fade:hint_range(0.0, 1.0, 0.01) = 1.0;
uniform vec3 camera_offset;
uniform sampler2D night_sky : filter_linear, source_color, hint_default_black;

//uniform samplerCube night_skycube : filter_linear, source_color, hint_default_black;

const vec3 UP = vec3( 0.0, 1.0, 0.0 );

// Sun constants
const float SOL_SIZE = 0.00872663806;
const float SUN_ENERGY = 1000.0;
 
// optical length at zenith for molecules
const float rayleigh_zenith_size = 8.4e3;
const float mie_zenith_size = 1.25e3;
//HEY!

// From: https://www.shadertoy.com/view/4sfGzS credit to iq
float hash(vec3 p) {
	p  = fract( p * 0.3183099 + 0.1 );
	p *= 17.0;
	return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}

// Utility function that maps a value from one range to another.
float remap(float originalValue,  float originalMin,  float originalMax,  float newMin,  float newMax) {
	return newMin + (((originalValue - originalMin) / (originalMax - originalMin)) * (newMax - newMin));
}

// Phase function
float henyey_greenstein(float cos_theta, float g) {
	const float k = 0.0795774715459;
	return k * (1.0 - g * g) / (pow(1.0 + g * g - 2.0 * g * cos_theta, 1.5));
}


float GetHeightFractionForPoint(float inPosition) {
	float height_fraction = (inPosition -  sky_b_radius) / (sky_t_radius - sky_b_radius);
	return clamp(height_fraction, 0.0, 1.0);
}

vec4 mixGradients(float cloudType){
	const vec4 STRATUS_GRADIENT = vec4(0.02f, 0.05f, 0.09f, 0.11f);
	const vec4 STRATOCUMULUS_GRADIENT = vec4(0.02f, 0.2f, 0.48f, 0.625f);
	const vec4 CUMULUS_GRADIENT = vec4(0.01f, 0.0625f, 0.78f, 1.0f);
	float stratus = 1.0f - clamp(cloudType * 2.0f, 0.0, 1.0);
	float stratocumulus = 1.0f - abs(cloudType - 0.5f) * 2.0f;
	float cumulus = clamp(cloudType - 0.5f, 0.0, 1.0) * 2.0f;
	return STRATUS_GRADIENT * stratus + STRATOCUMULUS_GRADIENT * stratocumulus + CUMULUS_GRADIENT * cumulus;
}

float densityHeightGradient(float heightFrac, float cloudType) {
	vec4 cloudGradient = mixGradients(cloudType);
	return smoothstep(cloudGradient.x, cloudGradient.y, heightFrac) - smoothstep(cloudGradient.z, cloudGradient.w, heightFrac);
}

float intersectSphere(vec3 pos, vec3 dir,float r) {
    float a = dot(dir, dir);
    float b = 2.0 * dot(dir, pos);
    float c = dot(pos, pos) - (r * r);
	float d = sqrt((b*b) - 4.0*a*c);
	float p = -b - d;
	float p2 = -b + d;
	if(p<0.0) return p2/(2.0*a);
	if(p2<0.0) return p/(2.0*a);
    return min(p, p2) / (2.0 * a);
}

vec2 intersectSphere2(vec3 pos, vec3 dir,float r) {
    float a = dot(dir, dir);
    float b = 2.0 * dot(dir, pos);
    float c = dot(pos, pos) - (r * r);
	float d = sqrt((b*b) - 4.0*a*c);
	float p = -b - d;
	float p2 = -b + d;
	//if(p<0.0) return p2/(2.0*a);
	//if(p2<0.0) return p/(2.0*a);
    return vec2(p, p2) / (2.0 * a);
}
// Returns density at a given point
// Heavily based on method from Schneider
float density(vec3 pip, vec3 weather, float mip, float height_fraction) {
	#if CURRENT_RENDERER == RENDERER_COMPATIBILITY  
	float time = 0.0;
	#else
	float time = TIME;
	#endif
	vec3 p = pip; 
	p.xz += time * 20.0 * normalize(wind_direction) * wind_speed * 0.6;
	vec4 n = textureLod(perlworlnoise, p.xyz*0.00008, mip-2.0);
	float fbm = n.g*0.625+n.b*0.25+n.a*0.125;
	float g = densityHeightGradient(height_fraction, weather.r);
	float base_cloud = remap(n.r, -(1.0-fbm), 1.0, 0.0, 1.0);
	//float weather_coverage = cloud_coverage*1.4+weather.b-1.0;
	float weather_coverage = cloud_coverage*weather.b;
	base_cloud = remap(base_cloud*g, 1.0-(weather_coverage), 1.0, 0.0, 1.0);
	base_cloud *= weather_coverage;
	p.xz -= time * normalize(wind_direction) * 40.;
	p.y -= time * 40.;
	vec3 hn = textureLod(worlnoise, p*0.001, mip).rgb;
	float hfbm = hn.r*0.625+hn.g*0.25+hn.b*0.125;
	hfbm = mix(hfbm, 1.0-hfbm, clamp(height_fraction*4.0, 0.0, 1.0));
	base_cloud = remap(base_cloud, hfbm*0.4 * height_fraction, 1.0, 0.0, 1.0);
	return pow(clamp(base_cloud, 0.0, 1.0), (1.0 - height_fraction) * 0.8 + 0.5);
}
vec3 sample_weather(vec2 pos,vec2 weather_pos){
	const float weather_scale = 0.00006;
	return //min(vec3(0.15,0.5,1.0), 
		texture(weathermap, pos * weather_scale + 0.5 + weather_pos).xyz
		//)
		//* texture(global_weathermap, pos * weather_scale*0.1 + 0.5 + weather_pos).xyz * 3.0)
		;
}
vec3 atmosphere(vec3 dir){
	return texture(cubemap,dir).xyz;
}
vec4 march(vec3 pos,  vec3 end, vec3 dir, int depth, vec2 uv) {
	const vec3 RANDOM_VECTORS[6] = {vec3( 0.38051305f,  0.92453449f, -0.02111345f),vec3(-0.50625799f, -0.03590792f, -0.86163418f),vec3(-0.32509218f, -0.94557439f,  0.01428793f),vec3( 0.09026238f, -0.27376545f,  0.95755165f),vec3( 0.28128598f,  0.42443639f, -0.86065785f),vec3(-0.16852403f,  0.14748697f,  0.97460106f)};
	float T = 1.0;
	float alpha = 0.0;
	float ss = length(dir);
	dir = dir/ss;
	
	float multiplier =1.0;//  float(depth)/30.0;

	vec3 p = pos;// + dir *  hash(vec3(uv,0) * 20.0) * ss;
	
	float lss = (t_dist / 36.0);
	vec3 ldir = normalize(LIGHT0_DIRECTION);
	vec3 L = vec3(0.0);
	int count=0;
	float t = 1.0;
	float costheta = dot(ldir, dir);
	// Stack multiple phase functions to emulate some backscattering
	float phase = max(max(henyey_greenstein(costheta, 0.6), henyey_greenstein(costheta, (0.4 - 1.4 * ldir.y))), henyey_greenstein(costheta, -0.2));
	// Precalculate sun and ambient colors
	// This should really come from a uniform or texture for performance reasons
	vec3 atmosphere_sun =   atmosphere(LIGHT0_DIRECTION) * LIGHT0_ENERGY * ss * 0.1;
	vec3 atmosphere_ambient =  atmosphere(normalize(vec3(1.0, 1.0, 0.0)));
	vec3 atmosphere_ground = atmosphere(normalize(vec3(1.0, -1.0, 0.0)));

	#ifdef RENDERER_COMPATIBILITY
	float time = 0.0 + 0.005 * _time_offset;
	#else
	float time = TIME * 0.001 + 0.005 * _time_offset;
	#endif 
	vec2 weather_pos = time * normalize(wind_direction) * wind_speed;
	//ss *=0.1;
	float ss2= ss ;
	for (int i = 0; i < depth; i++) {
		p += dir * ss2;
		ss2 *= 1.2;
		vec3 weather_sample = sample_weather(p.xz,weather_pos);
		float height_fraction =  GetHeightFractionForPoint(length(p));

		t = density(p, weather_sample, 0.0,height_fraction);
		float dt = exp(-_density*t*ss*multiplier);
		//T =  0.04*(pos.y-sky_b_radius)/(sky_t_radius-sky_b_radius) ;
		T *= dt;
		vec3 lp = p;
		float lt = 1.0;
		float cd = 0.0;

		if (t > 0.0) { //calculate lighting, but only when we are in the cloud
			//float lheight_fraction = 0.0; 
			 
			for (int j = 0; j < 2; j++) {
				lp += (ldir + RANDOM_VECTORS[j]*float(j))*lss;
				//lheight_fraction = GetHeightFractionForPoint(length(lp));
				vec3 lweather = sample_weather(lp.xz, weather_pos);
				lt = density(lp, lweather, float(j),height_fraction);
				cd += lt*4.0;
			} 

			// Take a single distant sample
			lp = p + ldir * 18.0 * lss;
			vec3 lweather = sample_weather( lp.xz, vec2(0,0)).xyz;
			lt = density(lp, lweather, 5.0,height_fraction);//
			//lheight_fraction = GetHeightFractionForPoint(length(lp));
			//lt = pow(density(lp, lweather, 5.0), (1.0 - lheight_fraction) * 0.8 + 0.5);
			cd += lt;

			// captures the direct lighting from the sun
			float beers = exp(-_density * cd * lss);
			float beers2 = exp(-_density * cd * lss * 0.25) * 0.7;
			float beers_total = max(beers, beers2);

			vec3 ambient = mix(atmosphere_ground*2.0, atmosphere_ambient, smoothstep(0.0, 1.0, height_fraction))
				* _density
				*height_fraction
				*500.0
				//*multiplier
				* mix(atmosphere_ambient, vec3(1.0), 0.4)
				//* (LIGHT0_DIRECTION.y) //idk looks too dark with this
				;
			alpha += (1.0 - dt) * (1.0 - alpha);
			L += (ambient + beers_total * atmosphere_sun * phase * alpha) * T * t;
			if(alpha>=1.0) break;
		}
	}
	return vec4( L, alpha);//   clamp(vec4( L, alpha), 0.0, 1.0);
}
vec4 getcolor(vec3 start, vec3 end, vec3 dir, float shelldist, vec2 uv)
{
	// Take fewer steps towards horizon
	//float steps =(mix(96.0*0.5, 54.0*0.175, clamp(dot(dir, vec3(0.0, 1.0, 0.0)), 0.0, 1.0)))*0.15;
	//float steps =96.0*0.5;// 54.0*0.15;//
	//float steps = (mix(96.0 , 54.0 , clamp(dot(dir, vec3(0.0, 1.0, 0.0)), 0.0, 1.0)));
	float steps = 25.0;
	vec3 raystep = dir * shelldist / steps;
	vec4 volume = march(start, end, raystep, int(steps), uv);
	//vec3 background = atmosphere(dir);// 0.1*vec3(1.0,1.0,1.0);//
	// Draw cloud shape
	vec4 col =  vec4(volume.xyz, volume.a);
	
	//col.xyz += texture(night_sky, SCREEN_UV).xyz; // * extinction
	// Blend distant clouds into the sky
	//col.xyz = mix(clamp(col.xyz, vec3(0.0), vec3(1.0)), clamp(background, vec3(0.0), vec3(1.0)), smoothstep(0.6, 1.0, 1.0-dir.y));
	////col.xyz = mix(col.xyz, background, smoothstep(0.6, 1.0, 1.0-dir.y));
	//col.xyz = mix(col.xyz, background, clamp(shelldist*0.00001,0.0,1.0));// smoothstep(0.6, 1.0, 1.0-dir.y));
	return col;
}

void sky() {
	vec3 dir = EYEDIR;
	 
	vec4 col = vec4(0.0);
	//if (dir.y>0.0)
	//{
		vec3 camPos = vec3(0.0, g_radius, 0.0)+POSITION+camera_offset;
		float camDist = length(camPos);
		float si1 = 0.0;
		float si2 = 0.0;
		float mul = 1.0;
		vec2 si1b = intersectSphere2(camPos, dir, sky_b_radius);
		vec2 si2b = intersectSphere2(camPos, dir, sky_t_radius);
		if(camDist<sky_b_radius){
			si1 = si1b.y;
			si2 = si2b.y; 
			mul = max(0.0,min(1.0,under_cutoff_distance-si1));
		}
		else if(camDist>sky_t_radius){  
			si1 = si2b.x;
			//si2 = min(si1b.x,si2b.y*0.5); 
			//mul =0.0;
			//si1 = 0.0;
			si2 =si2b.x+2000.0;
			mul = min(1.0,5000.0/si1);
		}
		else{ 
			si1 = 0.0;
			si2 =2000.0;//min(2000.0,si2b.y);//min(si2b.y*0.5,si1b.x)); 
		}
		//si1 = 0.0;
		//si2 =2000.0;
		si1 = max(0.0,si1);
		si2 = max(0.0,si2);
		vec3 start = camPos + dir * si1;
		vec3 end = camPos + dir * si2;
		float shelldist =si2-si1;// (length(end-start));
		if(mul>0.01){
			col = getcolor(start,end,dir,shelldist,SCREEN_UV)*mul;
			//if(shelldist>0.0001)
			//	col.a/=(shelldist*0.01);
		}
		 
		//col = mix(vec4(atmosphere_ambient_color*0.2,1),col,min(1.0, 2500.0/shelldist));
		//col = vec4(vec3(1,1,1)/(shelldist*0.01),1);
		//col = vec4(si1*0.00001,si2*0.00001,0,1);
		//col = vec4(shelldist*0.00001,0,0,1);
		//if(si1>si2){
		//	float t = si1;
		//	si1 = si2;
		//	si2 = t ;
		//}
		//si1 = max(0.0,si1);
		
		//fade 
		//float horizon = min(1.0,max(0.0, 
		//	 pow(1.0-max(0.0,dot(dir,vec3(0,1,0))),10.0)
		//	-(camDist-g_radius)*0.0005 ));
		float horizon = clamp(dot(dir,vec3(0,1,0))*10.0 -(camDist-sky_t_radius+2000.0)*0.0005,0.0,1.0);
		col.a *= horizon;
		//col = mix(col,vec4(atmosphere_ambient_color ,1.0),horizon);
		

	//} else {
	//col = vec4(atmosphere(dir,SCREEN_UV), 1.0);
	//}

	
	#if CURRENT_RENDERER == RENDERER_COMPATIBILITY  
	col = mix(texture(night_sky, SCREEN_UV),col,fade);
	COLOR = HALF_RES_COLOR.rgb;
	#else
	
	 
	if(AT_CUBEMAP_PASS){
		col =mix(texture(cubemap, EYEDIR*vec3(1,1,-1)),col,fade*col.a);
	}
	else{
		col = mix(texture(night_sky, SCREEN_UV),col,fade*col.a);
		//col =mix(texture(cubemap, EYEDIR*vec3(1,1,-1)),col,fade*col.a);
	}
	
	// Draw to quarter res buffer for reflections
	// Draw to half res buffer for main sky
	if (AT_QUARTER_RES_PASS && AT_CUBEMAP_PASS) {
		COLOR = col.xyz;
		ALPHA = 1.0;
	} else if (AT_HALF_RES_PASS && !AT_CUBEMAP_PASS) {
		COLOR = col.xyz;
		ALPHA = 1.0;
	} else if (AT_CUBEMAP_PASS) {
		COLOR = QUARTER_RES_COLOR.rgb;
	} else {
		//COLOR = HALF_RES_COLOR.rgb; // Change to col.rgb for full resolution
		COLOR = col.rgb;
	}
	#endif
}