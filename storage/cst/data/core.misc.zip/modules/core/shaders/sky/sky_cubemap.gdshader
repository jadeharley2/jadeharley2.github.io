shader_type sky;

uniform bool cubemap_only;
uniform bool use_srgb = false;
uniform sampler2D cameraview : filter_linear, source_color, hint_default_black;
uniform samplerCube cubemap : filter_linear, source_color;
uniform float cubemap_exposure = 1.0;

void sky() {
	if(AT_CUBEMAP_PASS){
		vec3 clr = texture(cubemap,EYEDIR*vec3(1,1,-1)).rgb;
		if(use_srgb){
    		COLOR =	cubemap_exposure*vec3(pow(clr.r, 2.2f),pow(clr.g, 2.2f),pow(clr.b, 2.2f));
		}
		else{
    		COLOR =	cubemap_exposure*clr;
		}
	}
	else{
		if(  cubemap_only){
			vec3 clr = texture(cubemap,EYEDIR*vec3(1,1,-1)).rgb;
			if(use_srgb){
	    		COLOR =	cubemap_exposure*vec3(pow(clr.r, 2.2f),pow(clr.g, 2.2f),pow(clr.b, 2.2f));
			}
			else{
	    		COLOR =	cubemap_exposure*clr;
			}
		}
		else{
			COLOR = texture(cameraview,SCREEN_UV).rgb;
		}
	}
}
