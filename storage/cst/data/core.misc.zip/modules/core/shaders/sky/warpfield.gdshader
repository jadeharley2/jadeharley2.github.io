shader_type sky;
uniform sampler3D noise : filter_linear_mipmap, repeat_enable;
uniform sampler2D gradient : filter_linear_mipmap;
uniform sampler2D night_sky : filter_linear, source_color, hint_default_black;
uniform vec3 camera_offset;
uniform float fade:hint_range(0.0, 1.0, 0.01) = 1.0;

const int STEPS = 10;
const float STEPS_INV = 1.0/float(STEPS);
void sky() {
	// Called for every visible pixel in the sky background, as well as all pixels
	// in the radiance cubemap.
	vec3 off = (camera_offset+POSITION)*0.001+vec3(TIME*0.01,0,0);
	float v = 0.0;
	vec3 c = vec3(0,0,0);
	if(!AT_CUBEMAP_PASS){
		c += texture(night_sky, SCREEN_UV).xyz;//+glow_color.xyz*0.0001*glow_power
	}
	for (int i = 0; i < STEPS; i++) {
		v = texture(noise, off+EYEDIR*float(i)*2.0*STEPS_INV).r/(float(i)*STEPS_INV+1.0)*1.0;
		v += texture(noise,off+EYEDIR*float(i)*20.0*STEPS_INV).r/(float(i)*STEPS_INV+1.0)*0.2;
		c += fade*pow(v,7)*texture(gradient,vec2(float(i)*0.1,0)).rgb;// vec3(0.0,0.5,1.0);
	}
	COLOR =c;//pow(v,3) * vec3(0.0,0.5,1.0);
}
