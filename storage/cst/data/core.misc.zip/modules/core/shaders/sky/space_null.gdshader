shader_type sky;

uniform float fade:hint_range(0.0, 1.0, 0.01) = 1.0;
uniform vec3 camera_offset;
uniform sampler2D night_sky : filter_linear, source_color, hint_default_black;
uniform samplerCube cubemap : filter_linear, source_color, hint_default_black;
uniform bool use_cubemap = false;

void sky() {
	if(AT_CUBEMAP_PASS){
		COLOR = texture(cubemap,EYEDIR*vec3(1,1,-1)).xyz;
	}
	else { 
		if(use_cubemap){
			COLOR = texture(cubemap,EYEDIR*vec3(1,1,-1)).xyz;
		}else{
			COLOR = texture(night_sky, SCREEN_UV).xyz;
		}
	}
}
