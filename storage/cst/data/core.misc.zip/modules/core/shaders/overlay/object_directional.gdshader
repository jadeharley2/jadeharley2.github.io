shader_type spatial;

render_mode blend_mix , diffuse_burley, specular_schlick_ggx, depth_draw_never;

uniform vec3 direction = vec3(0,1,0);
uniform float clip_value : hint_range(0.0, 1.0, 0.05) = 0.5;
uniform float intensity: hint_range(0.0, 1.0, 0.05) = 1.0;


uniform vec4 albedo : source_color = vec4(1,1,1,1) ;
uniform sampler2D albedo_texture : source_color, filter_nearest;
uniform sampler2D emit_texture : source_color, filter_nearest, hint_default_black;
uniform sampler2D texture_normal : hint_normal, filter_nearest;
uniform sampler2D texture_mask : hint_default_white, filter_nearest;
uniform vec4 emission : source_color = vec4(1,1,1,1) ;
uniform float specular: hint_range(0,1) = 0.5;
uniform float metallic: hint_range(-1,1) = 0.0;
uniform float roughness : hint_range(-1,1) = 1.0;
uniform float alpha_scissor_threshold : hint_range(0.0, 1.0);

varying float vblend;
void vertex() {
	// Called for every vertex the material is visible on.
	vec3 wnormal = normalize((MODEL_MATRIX * vec4(NORMAL,0.0) ).xyz);
	vblend = clamp((dot(wnormal,direction)-0.1)*intensity,0.0,1.0); //(dot(wnormal,direction)-0.1)*
}

void fragment() {  
	//if(vblend<clip_value){
	//	discard;
	//}
	ALPHA = vblend;
	vec4 VERTEX_WORLD = INV_VIEW_MATRIX * vec4(VERTEX, 1.0);
	
	
	vec2 base_uv = VERTEX_WORLD.xz;
	vec4 albedo_tex = texture(albedo_texture, base_uv);  

	vec3 rd = normalize(VERTEX_WORLD.xyz  - CAMERA_POSITION_WORLD) * 0.3 ;
 

	vec4 color0 = albedo_tex;
	ALBEDO = albedo.rgb *color0.rgb;
	// mix( albedo.rgb *color0.rgb,albedo_tex_2.rgb,clip_tex.r);//hsv2rgb(color0);
	vec4 mask = texture(texture_mask,base_uv);
	ROUGHNESS = mask.r + roughness;// * roughness_tex
	METALLIC = mask.b  + metallic;// * metallic_tex;
	SPECULAR = specular;

	vec3 nrmvec = (texture(texture_normal,base_uv).rgb-0.5)*2.0;
	nrmvec *=vec3(2,2,1);
	vec3 nrmclr = nrmvec*0.5+0.5;
	NORMAL_MAP = nrmclr;
	EMISSION = texture(emit_texture,base_uv).rgb*10.0*emission.rgb;
}

//void light() {
//	// Called for every pixel for every light affecting the material.
//	// Uncomment to replace the default light processing function with this one.
//}
