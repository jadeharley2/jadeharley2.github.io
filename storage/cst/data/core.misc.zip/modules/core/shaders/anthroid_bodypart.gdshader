shader_type spatial;

render_mode depth_prepass_alpha , diffuse_burley, specular_schlick_ggx, cull_disabled;

uniform sampler2D texture_albedo : source_color, filter_nearest;
uniform sampler2D texture_emit : source_color, filter_nearest, hint_default_black;
uniform sampler2D texture_normal : hint_normal, filter_nearest;
uniform sampler2D texture_mask : hint_default_black, filter_nearest;

uniform sampler2D texture_frame : source_color, filter_nearest;

uniform sampler2D texture_noise : hint_default_white, filter_nearest;

uniform vec4 albedo : source_color = vec4(1,1,1,1) ;
uniform vec4 emission : source_color = vec4(1,1,1,1) ;
uniform float specular: hint_range(0,1) = 0.5;
uniform float metallic: hint_range(-1,1) = 0.0;
uniform float roughness : hint_range(-1,1) = 1.0;
uniform float alpha_scissor_threshold : hint_range(0.0, 1.0) = 0.5;

uniform float damage : hint_range(0,2) = 0.0;

varying vec3 world_pos;
varying vec3 world_norm;
void vertex() {
	world_pos = VERTEX;
	world_norm = vec3(1.0,0,0);// NORMAL;
	// Called for every vertex the material is visible on.
}

void fragment() {
	vec2 base_uv = UV;
	vec4 nt_x =  texture(texture_noise, world_pos.yz);
	vec4 nt_y =  texture(texture_noise, world_pos.xz);
	vec4 nt_z =  texture(texture_noise, world_pos.xy);
	
	vec4 noise_tex = texture(texture_noise, floor(base_uv*256.0)/256.0*4.0);// mix(nt_x,nt_y,world_norm.y);
	
	vec4 albedo_tex = texture(texture_albedo, base_uv);
	vec4 frame_tex = texture(texture_frame, base_uv);
	if(noise_tex.r<damage-0.8){
		albedo_tex = frame_tex;
	}
	if(albedo_tex.a<alpha_scissor_threshold){
		discard;
	}
	
	vec4 mask = texture(texture_mask,base_uv);
	vec4 emit = texture(texture_emit,base_uv);
	
	vec4 color0 = albedo_tex;
	float vis_damage = clamp(pow(noise_tex.r-damage+0.6,0.9)*2.0,0.0,1.0);
	ALBEDO = albedo.rgb * color0.rgb * vis_damage; //max(0.0,1.0-pow(noise_tex.r-damage,4)); 
	ROUGHNESS = mix(mask.r + roughness,1.0,1.0-vis_damage);// * roughness_tex
	METALLIC = mix(mask.b  + metallic,0.0,1.0-vis_damage);// * metallic_tex;
	SPECULAR = specular;

	vec3 nrmvec = (texture(texture_normal,base_uv).rgb-0.5)*2.0;
	nrmvec *=vec3(2,2,1);
	vec3 nrmclr = nrmvec*0.5+0.5;
	NORMAL_MAP = nrmclr;
	EMISSION = emit.rgb*10.0*emission.rgb;
}

//void light() {
//	// Called for every pixel for every light affecting the material.
//	// Uncomment to replace the default light processing function with this one.
//}
