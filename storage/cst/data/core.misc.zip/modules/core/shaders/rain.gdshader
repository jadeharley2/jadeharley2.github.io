shader_type spatial; 
//render_mode blend_premul_alpha;

uniform vec4 albedo : source_color = vec4(1,1,1,1) ;

void fragment() { 
	ALBEDO = albedo.rgb;
	ALPHA =albedo.a;
}

void light() {
	//DIFFUSE_LIGHT = vec3(1.0);
	if(true && SPECULAR_AMOUNT>=128.0
		&&ATTENUATION<0.001
		&&LIGHT_COLOR.r<-1.0
		&&LIGHT_COLOR.g<-1.0
		&&LIGHT_COLOR.b<-1.0
		)// ATTENUATION>0.001){
	{
		ALPHA=0.0;
		//if(ATTENUATION<0.001){
		//
		//}
		//else{
		//	ALPHA = 1.0;//min(1.0, abs(ATTENUATION)*100.0);
		//}
		//DIFFUSE_LIGHT += clamp(dot(NORMAL, LIGHT), 0.0, 1.0) * ATTENUATION * LIGHT_COLOR / PI;
		//ATTENUATION;
	}
	else
	{
		//ALPHA -= ATTENUATION;
		//ALPHA=0.0;
		//ALPHA = 0.0;
		//discard;
		DIFFUSE_LIGHT += 1.0 * ATTENUATION * LIGHT_COLOR / PI;
	} 
	//DIFFUSE_LIGHT += clamp(dot(NORMAL, LIGHT), 0.0, 1.0) * ATTENUATION * LIGHT_COLOR / PI;
}
