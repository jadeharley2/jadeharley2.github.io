shader_type spatial;
render_mode diffuse_burley, specular_schlick_ggx, depth_draw_never, cull_disabled;
stencil_mode read, compare_greater, 1;

uniform sampler2D albedo_texture : source_color, filter_nearest, repeat_disable, hint_default_white;
uniform sampler2D specular_texture : source_color, filter_nearest, repeat_disable, hint_default_white;

#if CURRENT_RENDERER != RENDERER_COMPATIBILITY  
uniform sampler2D depth_tex_frg_20 : hint_depth_texture;
uniform sampler2D screen_tex : hint_screen_texture;
#endif
uniform vec4 ColorParameter : source_color;

uniform sampler2D normal1;
uniform vec2 wave_dir1 = vec2(1.0, 0.0);
uniform sampler2D normal2;
uniform vec2 wave_dir2 = vec2(0.0, 1.0);
uniform float wave_speed : hint_range(0.0, 0.2) = 0.035;

uniform float vertex_mul: hint_range(0.0, 4.0) = 1.0;
uniform float roughness: hint_range(0.01, 4.0) = 1;
uniform float specular: hint_range(0.01, 4.0) = 1;
uniform float metalness: hint_range(0.01, 4.0) = 1;

varying vec3 uv_world_pos;
uniform float wave_scale = 20.0;

global uniform float sync_time;
//global uniform vec3 global_bend_origin;
//global uniform float global_bend_power = 0.0001;

#include "wave.gdshaderinc"
#include "flow.gdshaderinc"


const float EPSILON = 1e-5;

uniform float ssr_resolution   : hint_range(0.01, 10.0, 0.1)	= 0.2;
uniform float ssr_max_travel   : hint_range(0.0, 200.0, 0.1) 	= 30;
uniform float ssr_max_diff     : hint_range(0.1, 10.0, 0.1) 	= 0.5;
uniform float ssr_mix_strength : hint_range(0.0, 1.0, 0.01) 	= 0.7;
uniform float ssr_screen_border_fadeout: hint_range(0.0, 1.0, 0.1)	= 0.3;


uniform sampler2D flowmap_test : hint_normal;

varying vec2 v_flow;
void vertex() {
	vec3 world_pos = VERTEX + NODE_POSITION_WORLD;
	vec3 in_norm = NORMAL;


	vec3 pos = vec3(0.0, 0.0, 0.0);
	vec3 norm  = vec3(0.0, 0.0, 0.0);

	vec3 fwp = world_pos*1000.0;
	float time = sync_time*10.0;
	float fScale =0.5;

	pos = ComplexWave(time,fwp)*vertex_mul;
	norm =  normalize(in_norm) - pos*fScale*1.0;
	pos.x = 0.0;
	pos.z = 0.0;
	pos.y -= 0.05;

	uv_world_pos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	VERTEX = pos + VERTEX;
	NORMAL = norm;

	v_flow = UV2;

	//float dist = distance(world_pos,global_bend_origin);
	//vec2 offsets = (world_pos-global_bend_origin).xz;
	//vec3 origin = vec3(global_bend_origin.x,0,global_bend_origin.z);
	//VERTEX = RotateVector(RotateVector(VERTEX+ NODE_POSITION_WORLD-origin,  vec3(1,0,0),offsets.y*global_bend_power),vec3(0,0,-1),offsets.x*global_bend_power)+origin-NODE_POSITION_WORLD;
	//NORMAL = RotateVector(RotateVector(NORMAL, vec3(1,0,0),offsets.y*global_bend_power ),vec3(0,0,-1),offsets.x*global_bend_power);


}


/* SSR CODE INCLUSION, MODIFIED
Copyright (c) 2023 - present Marcel Bankmann.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

vec2 get_uv_from_view_position(vec3 position_view_space, mat4 proj_m)
{
	vec4 position_clip_space = proj_m * vec4(position_view_space.xyz, 1.0);
	vec2 position_ndc = position_clip_space.xy / position_clip_space.w;
	return position_ndc.xy * 0.5 + 0.5;
}
vec3 get_view_position_from_uv(vec2 uv, float depth, mat4 inv_proj_m)
{
	vec4 position_ndc = vec4((uv * 2.0) - 1.0, depth, 1.0);
	vec4 view_position = inv_proj_m * position_ndc;
	return view_position.xyz /= view_position.w;
}
bool is_within_screen_boundaries(vec2 position) 
{
	return position.x > 0.0 && position.x < 1.0 && position.y > 0.0 && position.y < 1.0;
}

bool is_zero(float value) 
{
    return abs(value) < EPSILON;
}

float get_screen_border_alpha(vec2 screen_position)
{
    vec2 shifted_screen_position = 4.0 * screen_position * (1.0 - screen_position);
	float mask = shifted_screen_position.x * shifted_screen_position.y; // ranging from 0.0 at the edges to 1.0 in the center 

	// An offset in the [0.0, 0.5] range for ssr_screen_border_fadeout values > 0.75
	// which is subtracted from the result of smoothstep.
	// This ensure alpha smoothly transitions to zero when ssr_screen_border_fadeout is approaching 1.0.	
	float offset = mix(0.0, 0.5, (clamp(ssr_screen_border_fadeout, 0.75, 1.0)-0.75) / 0.25);
	float alpha = clamp(smoothstep(0.0, 2.0 * ssr_screen_border_fadeout, mask) - offset, 0.0, 1.0);

	return is_zero(ssr_screen_border_fadeout) ? 1.0 : alpha;
}

vec4 get_ssr_color(vec3 surface_view_position, vec3 normal_view_space, vec3 view_view_space, mat4 proj_m, mat4 inv_proj_m)
{
	if (ssr_max_travel < EPSILON)
	{
		return vec4(0);
	}
	
	vec3 current_position_view_space = surface_view_position;
	vec3 view_direction_view_space = view_view_space * -1.0;
	vec3 reflect_vector_view_space = normalize(reflect(view_direction_view_space.xyz, normal_view_space.xyz));
	
	vec2 current_screen_position = vec2(0.0);
	
	vec3 resulting_color = vec3(-1.0);
	for(float travel=0.0; 
		resulting_color.x < 0.0 && travel < ssr_max_travel; 
		travel = travel + ssr_resolution)
	{
		current_position_view_space += reflect_vector_view_space * ssr_resolution * max(1.0,travel)*0.1;
		current_screen_position = get_uv_from_view_position(current_position_view_space, proj_m);
		
		#if CURRENT_RENDERER == RENDERER_COMPATIBILITY  
		float depth_texture_probe_raw = 0.0;
		#else
		float depth_texture_probe_raw = texture(depth_tex_frg_20, current_screen_position).x;
		#endif
		vec3 depth_texture_probe_view_position = get_view_position_from_uv(current_screen_position, depth_texture_probe_raw, inv_proj_m);
		
		float depth_diff = depth_texture_probe_view_position.z - current_position_view_space.z;
		
		#if CURRENT_RENDERER == RENDERER_COMPATIBILITY  
		vec3 ssr_screen_color = vec3(0,0,0);
		#else
		vec3 ssr_screen_color = texture(screen_tex, current_screen_position.xy).rgb;
		//ssr_screen_color.x = depth_texture_probe_raw;
		#endif
		
		if(is_within_screen_boundaries(current_screen_position) 
			&& depth_diff >= 0.0 && depth_diff < ssr_max_diff){
			resulting_color = ssr_screen_color;
			//break;
		} 
	} 

	float alpha = get_screen_border_alpha(current_screen_position);
	return vec4(resulting_color,alpha);
}

/* END INCLUSION */

void fragment() {
	vec3 direction = (vec4(VERTEX,1) *  VIEW_MATRIX ).xyz;
	vec3 world_normal = normalize(NORMAL * mat3( VIEW_MATRIX));


	//vec4 flow_tex = COLOR;// texture(flowmap_test, UV);
	vec2 flow;
	//flow.x = -(flow_tex.g * 2.0 - 1.0);
	//flow.y = flow_tex.r * 2.0 - 1.0;
	flow.x = -(v_flow.y * 2.0 - 1.0);
	flow.y = v_flow.x * 2.0 - 1.0;

	vec2 l1;
	vec2 l2;
	float blend = uv_flow(uv_world_pos.xz / wave_scale,flow, l1, l2);

	// Normal maps
	vec2 normal_offset1 = (sync_time * wave_dir1) * wave_speed;
	vec2 normal_offset2 = (sync_time * wave_dir2) * wave_speed;
	vec3 wave_n0 = texture(normal1, uv_world_pos.xz / wave_scale + normal_offset1).rgb*2.0-1.0;
	vec3 wave_n1 = texture(normal1, uv_world_pos.xz / wave_scale + normal_offset2).rgb*2.0-1.0;
	vec3 wave_n2 = texture(normal1, (uv_world_pos.xz / wave_scale + normal_offset1)/8.0).rgb*2.0-1.0;
	vec3 wave_n3 = texture(normal1, (uv_world_pos.xz / wave_scale + normal_offset2)/8.0).rgb*2.0-1.0;
	vec3 normal_blend = ((wave_n0+wave_n1+wave_n2+wave_n3)*0.5+1.0 )/2.0;


	vec3 wave_f1 = texture(normal1, l1).rgb*2.0-1.0;
	vec3 wave_f2 = texture(normal1, l2).rgb*2.0-1.0;

	//normal_blend =mix(wave_f1,vec3(0.5,0.5,1),blend);// (mix(wave_f1,wave_f2,blend) ) ;
	//normal_blend =mix(vec3(0.5,0.5,1),wave_f2,blend);
	normal_blend =mix(wave_f1,wave_f2,blend);

	vec3 local_normal = normal_blend*2.0 -1.0;

	//vec2 refract_offset = NORMAL.xy*0.02+local_normal.xy*0.1;
	vec2 refract_offset = NORMAL.xy*0.02+normal_blend.xy*0.1;
	//refract_offset*=0.0;
	float visdot = pow(1.0-dot(world_normal,-normalize(direction)),2);
	
	#if CURRENT_RENDERER == RENDERER_COMPATIBILITY  
	float depth = 0.0;
	#else
	float depth = texture(depth_tex_frg_20, SCREEN_UV+refract_offset, 0.0).r;
	#endif
  	vec3 ndc = vec3(SCREEN_UV * 2.0 - 1.0, depth);
	vec4 world = INV_VIEW_MATRIX * INV_PROJECTION_MATRIX * vec4(ndc, 1.0);
	//vec4 linear_depth =  INV_PROJECTION_MATRIX * vec4(ndc, 1.0);
	//float linear_depth_z =  linear_depth.z/-linear_depth.w;
	float depth_texture_y = world.y / world.w;// min(1.0,);

	vec3 vertex_p = (INV_VIEW_MATRIX * vec4(VERTEX, 1.0)).xyz;
	float lqdepth = length(world.xyz/world.w - vertex_p )*0.4;

	//float vertex_y = (INV_VIEW_MATRIX * vec4(VERTEX, 1.0)).y;
	//float vertical_depth = vertex_y - depth_texture_y;// depth_texture_y;
	//float vertical_depth = linear_depth_z-vertex_y;// depth_texture_y;


	vec3 surface_view_position 	= get_view_position_from_uv(SCREEN_UV+refract_offset*4.0,  FRAGCOORD.z, INV_PROJECTION_MATRIX);
	
	vec4 ssr_color = get_ssr_color(surface_view_position, NORMAL, VIEW, PROJECTION_MATRIX, INV_PROJECTION_MATRIX);
	//vec3 surface_color_ssr_mix = (ssr_max_travel > EPSILON) ? mix(surface_depth_color_mix, ssr_color.rgb, ssr_mix_strength * ssr_color.a) : vec3(0);
	
	vec4 albedo_tex = texture(albedo_texture, UV);
	vec4 specular_tex = texture(specular_texture, UV);

	ROUGHNESS=specular_tex.r*roughness;
	METALLIC=specular_tex.g*metalness;
	SPECULAR=specular_tex.b*specular;
	float mixed_alpha = mix(visdot+lqdepth*0.5,1,albedo_tex.a*ColorParameter.a*COLOR.a);
	//ALPHA =  min(1,max(0,mixed_alpha)); //0.5
	//ALBEDO =  (albedo_tex*ColorParameter*COLOR).xyz;//0.1*linDepth*vec3(1,1,1);
	//ALBEDO = COLOR.rgb;
	//ALBEDO = NORMAL_MAP;
	//ALBEDO =vec3( mix(l1,l2,blend),0.0);
	float fog_value = clamp(mixed_alpha*0.3,0,1);
	#if CURRENT_RENDERER == RENDERER_COMPATIBILITY  
	ALPHA =0.8;
	#else
	EMISSION = clamp(1.0-fog_value,0,1)
			*1.0*mix(vec3(1,1,1),ColorParameter.rgb,fog_value)
			*texture(screen_tex,SCREEN_UV+refract_offset).rgb;
	#endif 
	ALBEDO =  vec3(0,0,0);
	//EMISSION += max(ssr_color.rgb* ssr_color.a * visdot,vec3(0,0,0));
	EMISSION = mix(EMISSION,max(ssr_color.rgb* ssr_color.a,vec3(0,0,0)),visdot);
	//EMISSION = vec3(visdot,visdot,visdot);
	
	if(NORMAL.y<0.0){
		float lfog =  clamp(length(direction)*0.04,0,1);
		EMISSION = mix(EMISSION,vec3(0,0,0),lfog);
		ALPHA = 1.0-lfog;
		//ALBEDO = mix(ALBEDO,ColorParameter.rgb,lfog);
		ROUGHNESS=(1.0-lfog)*specular_tex.r*roughness;
		METALLIC=(1.0-lfog)*specular_tex.g*metalness;
		SPECULAR=(1.0-lfog)*specular_tex.b*specular;
	}
	NORMAL_MAP = normal_blend*0.5+0.5;//+vec3(0.5,0.5,1.0);
	//RADIANCE = vec4(1,0,1,1);
	//ALBEDO =vec3(1.0,1.0,1.0)*length(world.xyz/world.w - vertex_p )*0.1;
	//vec3(1,1,1)*(vertex_y-(world.y/world.w));//
}
