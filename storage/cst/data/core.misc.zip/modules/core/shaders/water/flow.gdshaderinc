
uniform sampler2D texture_flow_noise;
uniform vec2 flow_noise_size = vec2(1.0, 1.0);
uniform float flow_noise_influence = 0.5;
uniform float blend_cycle = 1.0;
uniform float cycle_speed = 1.0;
uniform float flow_speed =  0.5;
uniform vec2 uv_scale = vec2(1.0, 1.0);
uniform vec2 channel_flow_direction = vec2(1.0, -1.0);
uniform float flow_normal_influence : hint_range(0, 1);

// UV flow  calculation
float uv_flow(vec2 uv, vec2 flow,
		out vec2 layer1, out vec2 layer2){
	float half_cycle = blend_cycle * 0.5;

	// Use noise texture for offset to reduce pulsing effect
	float offset = texture(texture_flow_noise, uv * flow_noise_size).r * flow_noise_influence;

	float phase1 = mod(offset + TIME * cycle_speed, blend_cycle);
	float phase2 = mod(offset + TIME * cycle_speed + half_cycle, blend_cycle);

	flow *= normalize(channel_flow_direction);

	// Make flow incluence on the normalmap strenght adjustable (optional)
	float normal_influence = mix(1.0, dot(abs(flow), vec2(1.0, 1.0)) * 0.5, flow_normal_influence);

	// Blend factor to mix the two layers
	float blend_factor = abs(half_cycle - phase1)/half_cycle;

	// Offset by halfCycle to improve the animation for color (for normalmap not absolutely necessary)
	phase1 -= half_cycle;
	phase2 -= half_cycle;

	// Multiply with scale to make flow speed independent from the uv scaling
	flow *= flow_speed * uv_scale;

	layer1 = flow * phase1 + uv;
	layer2 = flow * phase2 + uv;
	return blend_factor;
}

/*
code adapted from: https://github.com/JaccomoLorenz/godot-flow-map-shader

original license:
The shader, the demo and all parts of this project that are not copyrighted or licensed by someone else are released under the MIT License:

Copyright (c) 2018 Jaccomo Lorenz (Maujoe)

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/