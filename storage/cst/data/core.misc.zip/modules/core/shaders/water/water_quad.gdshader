shader_type spatial;
render_mode  depth_draw_never;
//unshaded,
uniform vec4 ColorParameter : source_color;
uniform sampler2D depth_tex_frg_20 : hint_depth_texture;
uniform float vertex_mul: hint_range(0.0, 4.0) = 1.0;

global uniform float sync_time;

#include "wave.gdshaderinc"

void light() {
	// light we wish to accumulate
	DIFFUSE_LIGHT += ALBEDO * ATTENUATION * LIGHT_COLOR  ;
}
void fragment() {

	vec3 vertex_p = (INV_VIEW_MATRIX * vec4(VERTEX, 1.0)).xyz;

	vec3 fwp = vertex_p*1000.0;
	float time = sync_time*10.0;
	vec3 wave_at_pos = (ComplexWave(time,fwp)*vertex_mul);

	float sep = wave_at_pos.y-vertex_p.y+1.742;//+1.736
	if(sep<0.0)
	{
		discard;
	}
	float depth = texture(depth_tex_frg_20, SCREEN_UV, 0.0).r;
	vec4 xprojpos = INV_PROJECTION_MATRIX * vec4(SCREEN_UV * 2.0 - 1.0,depth, 1.0);
	float xdepth = -xprojpos.z/xprojpos.w;

	float dexp_fog = 1.0 - 1.0/exp(xdepth*0.2);

	ALPHA = max(0.0,min(1.0,dexp_fog));
	ALBEDO = ColorParameter.rgb*ALPHA;
}
