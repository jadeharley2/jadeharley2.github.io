
vec3 WaveFunction(float Amplitude, float Steepness, float NumWaves, float WaveLength,
	float Speed, float Time, vec3 Direction, vec3 WorldPosition)
{
	float w = TAU/WaveLength;
	float wDot = w * dot(normalize(Direction),vec3(WorldPosition.x,0,WorldPosition.z));
	float wSTDot = w * Speed * Time + wDot;
	float Qi = Steepness/(w*Amplitude*(NumWaves*TAU));
	float QA = Qi * Amplitude;

	vec3 shift = vec3(0,0,0) ;
	shift.xz = Direction.xz*QA*cos(wSTDot);
	shift.y = 2.0*Amplitude*sin(wSTDot);
	return shift;
}


vec3 RotateVector(vec3 point, vec3 axis, float angle)
{
    vec3 vxp = cross(axis, point);
    vec3 vxvxp = cross(axis, vxp);
    return point + sin(angle) * vxp + (1.0 - cos(angle)) * vxvxp;
}

vec3 ComplexWave(float time,vec3 fwp)
{
	vec3 sHigh = 0.0
		+WaveFunction(1000.0,1,2,80000,1000,time,vec3(0.5,0,0.7),fwp)
	 	+WaveFunction(800.0,1,2,40000,500,time,vec3(0,0,-0.5),fwp)
		;
	vec3 sMed = 0.0
	 	+WaveFunction(200.0,1,2,13245,1000,time,vec3(0.2,0,0.6),fwp)
	 	+WaveFunction(100.0,1,2,11134,500,time,vec3(-0.3,0,-0.3),fwp);
	vec3 sSml = 0.0
	 	+WaveFunction(70.0,0.5,2,6324,100,time,vec3(-0.3,0,0.7),fwp)
	 	//+WaveFunction(0.5,0.5,2,400,200,time,float3(0.5,0,0.7),fwp)
	 	//+WaveFunction(0.7,0.5,2,800,300,time,float3(0.4,0,0.7),fwp)
		 ;
	//pos = vertex_mul*(sHigh +  sMed + sSml)*vec3(0.0,0.0005,0.0)-vec3(0.0,0.2,0.0);//*vec3(0.001,0.0005,0.001);
	return (sHigh +  sMed + sSml)*0.0005-vec3(0.0,0.2,0.0);//*vec3(0.001,0.0005,0.001);

}