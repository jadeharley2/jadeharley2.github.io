shader_type spatial;
render_mode diffuse_burley, specular_schlick_ggx, depth_draw_opaque;
//diffuse_toon

uniform sampler2D albedo_texture : source_color, filter_nearest, repeat_disable, hint_default_white;
uniform sampler2D specular_texture : source_color, filter_nearest, repeat_disable, hint_default_white;

uniform sampler2D depth_tex_frg_20 : hint_depth_texture;
uniform sampler2D screen_tex : hint_screen_texture;
uniform vec4 ColorParameter : source_color;

uniform sampler2D normal1;
uniform vec2 wave_dir1 = vec2(1.0, 0.0);
uniform sampler2D normal2;
uniform vec2 wave_dir2 = vec2(0.0, 1.0);
uniform float wave_speed : hint_range(0.0, 0.2) = 0.035;

uniform float vertex_mul: hint_range(0.0, 4.0) = 1.0;
uniform float roughness: hint_range(0.01, 4.0) = 1;
uniform float specular: hint_range(0.01, 4.0) = 1;
uniform float metalness: hint_range(0.01, 4.0) = 1;

varying vec3 uv_world_pos;
uniform float wave_scale = 20.0;
global uniform float sync_time;

//global uniform vec3 global_bend_origin;
//global uniform float global_bend_power = 0.0001;

#include "wave.gdshaderinc"

void vertex() {
	vec3 world_pos = VERTEX + NODE_POSITION_WORLD;
	vec3 in_norm = NORMAL;


	vec3 pos = vec3(0.0, 0.0, 0.0);
	vec3 norm  = vec3(0.0, 0.0, 0.0);

	vec3 fwp = world_pos*1000.0;
	float time = sync_time*10.0;

	float fScale =0.5;
	pos = ComplexWave(time,fwp)*vertex_mul;
	norm =  normalize(in_norm) - pos*fScale;
	pos.x = 0.0;
	pos.z = 0.0;


	uv_world_pos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	VERTEX = pos + VERTEX;
	NORMAL = norm;



	//float dist = distance(world_pos,global_bend_origin);
	//vec2 offsets = (world_pos-global_bend_origin).xz;
	//vec3 origin = vec3(global_bend_origin.x,0,global_bend_origin.z);
	//VERTEX = RotateVector(RotateVector(VERTEX+ NODE_POSITION_WORLD-origin,  vec3(1,0,0),offsets.y*global_bend_power),vec3(0,0,-1),offsets.x*global_bend_power)+origin-NODE_POSITION_WORLD;
	//NORMAL = RotateVector(RotateVector(NORMAL, vec3(1,0,0),offsets.y*global_bend_power ),vec3(0,0,-1),offsets.x*global_bend_power);


}

vec3 reconstructPosition(in vec2 uv, in float z, in mat4 InvVP)
{
  float x = uv.x * 2.0f - 1.0f;
  float y = (1.0 - uv.y) * 2.0f - 1.0f;
  vec4 position_s = vec4(x, y, z, 1.0f);
  vec4 position_v = InvVP * position_s;
  return position_v.xyz / position_v.w;
}
vec3 reconstructNormal(vec2 uv0, float depth_dimensions, mat4 InverseViewProjection){
	vec2 uv1 = uv0 + vec2(1, 0) / depth_dimensions; // right
	vec2 uv2 = uv0 + vec2(0, 1) / depth_dimensions; // top

	float depth0 = texture(depth_tex_frg_20, uv0, 0).r;
	float depth1 = texture(depth_tex_frg_20, uv1, 0).r;
	float depth2 = texture(depth_tex_frg_20, uv2, 0).r;

	vec3 P0 = reconstructPosition(uv0, depth0, InverseViewProjection);
	vec3 P1 = reconstructPosition(uv1, depth1, InverseViewProjection);
	vec3 P2 = reconstructPosition(uv2, depth2, InverseViewProjection);

	return normalize(cross(P2 - P0, P1 - P0));
}
void fragment() {
	vec3 direction = (vec4(VERTEX,1) *  VIEW_MATRIX ).xyz;
	vec3 world_normal = normalize(NORMAL * mat3( VIEW_MATRIX));

	float visdot = pow(1.0-dot(world_normal,-normalize(direction)),2);

	float depth = texture(depth_tex_frg_20, SCREEN_UV, 0.0).r;


  	vec3 ndc = vec3(SCREEN_UV * 2.0 - 1.0, depth);
	vec4 world = INV_VIEW_MATRIX * INV_PROJECTION_MATRIX * vec4(ndc, 1.0);

	//vec4 linear_depth =  INV_PROJECTION_MATRIX * vec4(ndc, 1.0);
	//float linear_depth_z =  linear_depth.z/-linear_depth.w;
	float depth_texture_y = world.y / world.w;// min(1.0,);


	vec3 vertex_p = (INV_VIEW_MATRIX * vec4(VERTEX, 1.0)).xyz;
	float lqdepth = length(world.xyz/world.w - vertex_p );

	//float vertex_y = (INV_VIEW_MATRIX * vec4(VERTEX, 1.0)).y;
	//float vertical_depth = vertex_y - depth_texture_y;// depth_texture_y;
	//float vertical_depth = linear_depth_z-vertex_y;// depth_texture_y;

	// Normal maps
	vec2 normal_offset1 = (sync_time * wave_dir1) * wave_speed;
	vec2 normal_offset2 = (sync_time * wave_dir2) * wave_speed;
	vec3 normal_blend = mix(texture(normal1, uv_world_pos.xz / wave_scale + normal_offset1), texture(normal2, uv_world_pos.xz / wave_scale + normal_offset2), 0.5).rgb;

	vec4 albedo_tex = texture(albedo_texture, UV);
	vec4 specular_tex = texture(specular_texture, UV);

	vec3 rnorm = reconstructNormal(SCREEN_UV,2048,INV_PROJECTION_MATRIX);

	vec4 vertex_x = (INV_VIEW_MATRIX * vec4(VERTEX, 1.0));
	float surfdepth = vertex_x.z/vertex_x.w;


	vec3 surface_wpos = vertex_p;
	vec3 pixel_wpos = world.xyz / world.w;

	vec4 xprojpos = INV_PROJECTION_MATRIX * vec4(SCREEN_UV * 2.0 - 1.0,depth, 1.0);
	float xdepth = xprojpos.z/xprojpos.w;

	float maxdepth = max(xdepth,VERTEX.z);
	float fog = max(0.0,min(1.0,maxdepth*-0.1));

	fog = clamp(length(vertex_p -CAMERA_POSITION_WORLD)*0.01,0,1);

	//ALBEDO = vec3(mod(length(pixel_wpos -vertex_p),1.0),0,0);
	ALBEDO = ColorParameter.rgb*ColorParameter.a ;//ColorParameter.rgb*fog;
	//ALBEDO = ColorParameter.rgb;
	vec3 local_normal = normal_blend*2.0 -1.0;
	EMISSION = ColorParameter.rgb*texture(screen_tex,SCREEN_UV+NORMAL.xy*0.1+local_normal.xy*0.2).rgb;
	NORMAL_MAP = normal_blend;
	//ALBEDO = vec3(mod(xdepth.z/xdepth.w,1) ,0,0);
	//NORMAL_MAP = (rnorm-vec3(1,1,1))*0.5; //normal_blend;
	ROUGHNESS=1.0;//specular_tex.r*roughness;
	METALLIC=1.0;//specular_tex.g*metalness;
	//SPECULAR=specular_tex.b*specular;
	//float mixed_alpha = mix(visdot+lqdepth*0.5,1,albedo_tex.a*ColorParameter.a);

	vec3 surface_direction = normalize(surface_wpos-CAMERA_POSITION_WORLD);
	float exit_alpha = max(0.0,1.0- dot(world_normal,surface_direction));

	//ALPHA = 0.0;// min(1.0,fog+exit_alpha); //  min(1,max(0,mixed_alpha)); //0.5
	// vec3(1.0,1.0,1.0);// (albedo_tex*ColorParameter).xyz;//0.1*linDepth*vec3(1,1,1);

	//ALBEDO =vec3(1.0,1.0,1.0)*length(world.xyz/world.w - vertex_p )*0.1;
	//vec3(1,1,1)*(vertex_y-(world.y/world.w));//
}
