shader_type spatial;
render_mode  depth_draw_never;
//unshaded,
uniform vec4 ColorParameter : source_color;
uniform sampler2D depth_tex_frg_20 : hint_depth_texture;



void light() {
	// light we wish to accumulate
	DIFFUSE_LIGHT += ALBEDO * ATTENUATION * LIGHT_COLOR  ;
}
void fragment() {

	vec3 vertex_p = (INV_VIEW_MATRIX * vec4(VERTEX, 1.0)).xyz;

	

	float depth = texture(depth_tex_frg_20, SCREEN_UV, 0.0).r;
	//if(depth<0.0001) {
	//	depth = 1.0; 
	//}
	vec4 xprojpos = INV_PROJECTION_MATRIX * vec4(SCREEN_UV * 2.0 - 1.0,depth, 1.0);
	float xdepth = -xprojpos.z/xprojpos.w;

	float dexp_fog = 1.0 - 1.0/exp(xdepth*0.2);

	ALPHA = max(0.0,min(1.0,dexp_fog));
	ALBEDO = ColorParameter.rgb*ALPHA;
	
	//ALPHA =1.0;
	//ALBEDO = vec3(1,1,1)*depth*10.0;
}
