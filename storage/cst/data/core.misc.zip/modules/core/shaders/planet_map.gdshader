shader_type spatial;

uniform sampler2D albedo_texture : source_color, filter_nearest, repeat_disable;
uniform sampler2D height_texture : source_color, filter_linear_mipmap, repeat_disable;
uniform sampler2D glow_texture : source_color, filter_nearest, repeat_disable, hint_default_black;

uniform vec3 water_color: source_color;
uniform vec3 coast_color: source_color;
uniform vec3 side_color: source_color;

void vertex() {
}

void fragment() {
	float height = texture(height_texture,UV).x*256.0-80.0;
	vec4 albedo_tex = texture(albedo_texture, UV);
	ALBEDO = albedo_tex.rgb;
	EMISSION = texture(glow_texture,UV).rgb;
	if(height<0.2){
		ALBEDO = water_color;
	}
	else if(height<4.0){
		ALBEDO = coast_color;
	}
}
