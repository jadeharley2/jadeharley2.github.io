
void doclip(mat4 INV_VIEW_MATRIX, vec3 VERTEX){ 
	vec4 VERTEX_WORLD = INV_VIEW_MATRIX * vec4(VERTEX, 1.0);
	if(VERTEX_WORLD.x<0.0){
		 
	}
}