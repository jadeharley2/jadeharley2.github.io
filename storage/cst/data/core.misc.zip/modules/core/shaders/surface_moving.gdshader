shader_type spatial;

render_mode depth_prepass_alpha , diffuse_burley, specular_schlick_ggx;

uniform vec4 tint : source_color = vec4(1,1,1,1) ;  
uniform sampler2D albedo_texture : source_color, filter_nearest, hint_default_black;
uniform sampler2D texture_normal : hint_normal, filter_nearest;
uniform sampler2D mask_texture : source_color, filter_nearest, hint_default_black;

uniform vec2 movement = vec2(1,0);
uniform float specular: hint_range(0,1) = 0.5;

global uniform vec4 clip_plane0;


void fragment() {
	vec4 VERTEX_WORLD = INV_VIEW_MATRIX * vec4(VERTEX, 1.0);
	if(dot(VERTEX_WORLD.xyz,clip_plane0.xyz)<clip_plane0.w){ 
		discard;
	}
	vec2 base_uv = UV+movement* TIME;
	ALBEDO =  texture(albedo_texture,base_uv).rgb*tint.rgb*COLOR.rgb;
	vec4 mask = texture(mask_texture,base_uv);
	NORMAL_MAP = texture(texture_normal,base_uv).rgb;
	ROUGHNESS = mask.r;// * roughness_tex
	METALLIC = mask.b ;// * metallic_tex;
	SPECULAR = specular;
}
