shader_type fog;

uniform sampler2D emit_texture : source_color, hint_default_white;
uniform sampler2D noise0 : source_color, hint_default_white;

void fog() {
	// Called once for every froxel that is touched by an axis-aligned bounding box
	// of the associated FogVolume. This means that froxels that just barely touch
	// a given FogVolume will still be used.
	vec4 sample = texture(emit_texture,vec2(UVW.xz));
	EMISSION = sample.rgb*1.0;
	//EMISSION = UVW;
	DENSITY = 1.0;// (sample.r+sample.g+sample.b) /3.0;
}
