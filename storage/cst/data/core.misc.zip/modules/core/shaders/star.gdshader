shader_type spatial;


uniform float Brightness = 1.0;
uniform vec3 Color: source_color = vec3(1,1,1);

uniform sampler2D noise : source_color, filter_nearest, hint_default_white;

varying float cameradot;
void vertex() {
	cameradot =pow(1.0- dot(normalize(CAMERA_POSITION_WORLD- VERTEX),NORMAL),2)*7.0+0.5;
	// Called for every vertex the material is visible on.
}

void fragment() {
	vec3 noisex = texture(noise,UV+vec2(TIME*-0.0001,TIME*0.0002)).rgb;
	vec3 noisey = texture(noise,UV+vec2(TIME*0.001,0)).rgb;
	vec3 noisez = texture(noise,UV+vec2(TIME*0.00006,TIME*-0.00012)).rgb;
	float polarx = pow(UV.y-0.5,2)+0.1;
	ALBEDO = vec3(0,0,0);
	//EMISSION = vec3(1,1,1)*cameradot;
	EMISSION = Color*Brightness*10.0*mix(noisex.x*noisey.x*noisez.x*3.0,1,polarx)*cameradot;

}

//void light() {
	// Called for every pixel for every light affecting the material.
	// Uncomment to replace the default light processing function with this one.
//}
