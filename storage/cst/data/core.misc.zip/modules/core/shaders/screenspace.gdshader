shader_type spatial;


uniform sampler2D albedo_texture : source_color;

void vertex() {
	// Called for every vertex the material is visible on.
}

void fragment() {
	ALBEDO = vec3(0.0,0.0,0.0);
	EMISSION = texture(albedo_texture, SCREEN_UV).rgb;
}

