shader_type spatial;

render_mode blend_mix,  depth_prepass_alpha , cull_disabled, diffuse_burley, specular_schlick_ggx, skip_vertex_transform;

uniform vec4 albedo : source_color ;
uniform sampler2D albedo_texture : source_color, filter_nearest;
uniform float specular=0.5;
uniform float metallic;
uniform float roughness : hint_range(0,1) = 1.0;
uniform float alpha_scissor_threshold : hint_range(0.0, 1.0); 
uniform sampler2D texture_metallic : hint_default_white, filter_nearest;
uniform vec4 metallic_texture_channel;
uniform sampler2D texture_roughness : hint_default_white, filter_nearest;
uniform vec4 roughness_texture_channel;
//uniform vec4 transmission : source_color;
//uniform sampler2D texture_transmission : hint_default_black, filter_nearest;

uniform float wind_speed = 1.0;
uniform vec2 wind_direction = vec2(1.0, 0.0);
uniform float wind_strength_min : hint_range(0.0, 1.0);
uniform float wind_strength_max : hint_range(0.0, 1.0);
uniform float wind_distortion : hint_range(0.0, 1.0);
uniform float wind_interval = 3.5;
uniform float detail = 1.0;
uniform float height_offset = 0.0;

uniform vec3 uv1_scale;
uniform vec3 uv1_offset;

global uniform vec4 clip_plane0;

vec3 wind(mat4 worldMatrix, vec3 vertex, float timer){
	vec4 pos = worldMatrix * mix(vec4(1.0), vec4(vertex, 1.0), wind_distortion);
	float time = timer * wind_speed + pos.x + pos.z;
	float diff = pow(wind_strength_max - wind_strength_min, 2);
	float strength = clamp(wind_strength_min + diff + sin(time / wind_interval) * diff, wind_strength_min, wind_strength_max);
	float wind = (sin(time) + cos(time * detail)) * strength * max(0.0, vertex.y - height_offset);
	vec2 dir = normalize(wind_direction);
	
	return vec3(wind * dir.x, 0.0, wind * dir.y);
}
void vertex() {
	vec4 worldPos = MODEL_MATRIX * vec4(VERTEX, 1.0);
	worldPos.xyz += wind(MODEL_MATRIX, VERTEX, TIME);
	VERTEX = (VIEW_MATRIX * worldPos).xyz;
	NORMAL = (MODELVIEW_MATRIX * vec4(NORMAL, 0.0)).xyz;
	UV = UV * uv1_scale.xy + uv1_offset.xy;
}

void fragment() {
	vec4 VERTEX_WORLD = INV_VIEW_MATRIX * vec4(VERTEX, 1.0);
	if(dot(VERTEX_WORLD.xyz,clip_plane0.xyz)<clip_plane0.w){ 
		discard;
	}
	
	vec2 base_uv = UV;
	vec4 albedo_tex = texture(albedo_texture, base_uv);
	ALBEDO = albedo.rgb * albedo_tex.rgb;
	float metallic_tex = dot(texture(texture_metallic,base_uv), metallic_texture_channel);
	METALLIC = metallic;// * metallic_tex;
	float roughness_tex = dot(texture(texture_roughness,base_uv), roughness_texture_channel);
	ROUGHNESS = roughness;// * roughness_tex
	SPECULAR = specular;
	//vec3 transmission_tex = texture(texture_transmission, base_uv).rgb;
	//TRANSMISSION = (transmission.rgb + transmission_tex);
	ALPHA = albedo.a * albedo_tex.a;
	ALPHA_SCISSOR_THRESHOLD = alpha_scissor_threshold;
}
