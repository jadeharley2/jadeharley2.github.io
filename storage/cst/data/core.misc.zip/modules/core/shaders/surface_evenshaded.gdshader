shader_type spatial;

render_mode depth_prepass_alpha , diffuse_burley, specular_schlick_ggx, cull_disabled;

uniform vec4 albedo : source_color = vec4(1,1,1,1) ;
uniform sampler2D albedo_texture : source_color, filter_nearest;
uniform vec4 emission : source_color = vec4(1,1,1,1) ;
uniform sampler2D emit_texture : source_color, filter_nearest, hint_default_black;
uniform sampler2D albedo2_texture : source_color, filter_nearest;
uniform sampler2D texture_normal : hint_normal, filter_nearest;
uniform float specular: hint_range(0,1) = 0.5;
uniform float metallic: hint_range(-1,1) = 0.0;
uniform float roughness : hint_range(-1,1) = 1.0;
uniform float alpha_scissor_threshold : hint_range(0.0, 1.0);

uniform vec2 noise_uv_scale = vec2(10,10);
uniform sampler2D noise_texture : hint_default_white;
uniform float noise_shift_mul : hint_range(-1.0, 1.0) = 0.1;
uniform sampler2D noise_texture2 : hint_default_black;

global uniform vec4 clip_plane0;

varying vec3 world_pos;
void vertex()
{
	world_pos = ( MODEL_MATRIX * vec4( VERTEX, 1.0 ) ).xyz;
	//vec4 noise_tex = texture(noise_texture2,world_pos.xz*noise_uv_scale);
	//world_pos+=vec3(noise_tex.x-0.5,0,0);
	//VERTEX = ( inverse(MODEL_MATRIX) * vec4( world_pos, 1.0 ) ).xyz;
}

void fragment() {
	vec4 VERTEX_WORLD = INV_VIEW_MATRIX * vec4(VERTEX, 1.0);
	if(dot(VERTEX_WORLD.xyz,clip_plane0.xyz)<clip_plane0.w){
		discard;
	}

	vec2 base_uv = UV;
	vec4 albedo_tex = texture(albedo_texture, base_uv);
	//vec4 albedo2_tex = texture(albedo2_texture, base_uv);
	vec4 noise_tex = texture(noise_texture,world_pos.xz*noise_uv_scale);

	vec4 color0 = albedo_tex;// mix(albedo_tex,albedo2_tex,noise_tex);//rgb2hsv( albedo_tex.rgb);
	//color0.y =color0.y+(noise_tex.r-0.5)*noise_shift_mul;
	ALBEDO =  albedo.rgb *color0.rgb;//hsv2rgb(color0);
	ROUGHNESS = roughness;// * roughness_tex
	METALLIC =  metallic;// * metallic_tex;
	SPECULAR = specular;

	NORMAL_MAP = texture(texture_normal,base_uv).rgb;
	EMISSION = texture(emit_texture,base_uv).rgb*10.0*emission.rgb;
	//vec3 transmission_tex = texture(texture_transmission, base_uv).rgb;
	//TRANSMISSION = (transmission.rgb + transmission_tex);
	ALPHA = albedo.a * albedo_tex.a;
	ALPHA_SCISSOR_THRESHOLD = alpha_scissor_threshold;
}
void light() {
	// Called for every pixel for every light affecting the material.
	// Uncomment to replace the default light processing function with this one.
	DIFFUSE_LIGHT += ATTENUATION * LIGHT_COLOR;
}
