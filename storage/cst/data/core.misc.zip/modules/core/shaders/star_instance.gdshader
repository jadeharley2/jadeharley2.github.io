shader_type spatial;
render_mode blend_add, depth_draw_opaque, cull_back, diffuse_lambert, specular_disabled, unshaded;

uniform sampler2D star : source_color;
uniform float brightness = 100.0;


varying float dsq;
varying float br2;

void vertex() {
	mat4 bmatrix;
// GetBillboardMatrix:2
	{
		vec4 vp = VIEW_MATRIX * MODEL_MATRIX[3];
		vec3 xscale = vec3(1,1,1)*min(vp.z,-1.0)*0.2;
		dsq = vp.z*vp.z;
		br2 = INSTANCE_CUSTOM.r;

		mat4 __wm = mat4(
			normalize(INV_VIEW_MATRIX[0])*xscale.x,
			normalize(INV_VIEW_MATRIX[1])*xscale.y,
			normalize(INV_VIEW_MATRIX[2]),
			MODEL_MATRIX[3]);
		//__wm *= mat4(
		//	vec4(cos(INSTANCE_CUSTOM.x), -sin(INSTANCE_CUSTOM.x), 0.0, 0.0),
		//	vec4(sin(INSTANCE_CUSTOM.x), cos(INSTANCE_CUSTOM.x), 0.0, 0.0),
		//	vec4(0.0, 0.0, 1.0, 0.0),
		//	vec4(0.0, 0.0, 0.0, 1.0));
		//__wm *= mat4(
		//	vec4(length(MODEL_MATRIX[0].xyz), 0.0, 0.0, 0.0),
		//	vec4(0.0, length(MODEL_MATRIX[1].xyz), 0.0, 0.0),
		//	vec4(0.0, 0.0, length(MODEL_MATRIX[2].xyz), 0.0),
		//	vec4(0.0, 0.0, 0.0, 1.0));
		bmatrix = VIEW_MATRIX * __wm;
	}


	MODELVIEW_MATRIX = bmatrix;


}

void fragment() {
	vec4 col = texture(star, UV);

	ALBEDO =  COLOR.xyz * ( col.x*brightness);
	ALPHA = col.x *10.0* br2 / dsq;
}
