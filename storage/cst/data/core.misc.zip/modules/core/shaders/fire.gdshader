shader_type spatial;
render_mode blend_add, unshaded;

uniform float Emit : hint_range(0.0, 100.0, 0.1);
uniform vec3 Color : source_color = vec3(1,0.5,0.1);
uniform sampler2D clamp0 : source_color, hint_default_white;
uniform sampler2D noise0 : source_color, hint_default_white;




void fragment() {
	float c0 = texture(clamp0,UV).r;
	float n0 = texture(noise0,UV+vec2(0,TIME)).r;
	float n1 = texture(noise0,UV*0.5+vec2(TIME,-TIME)*0.5).r;
	float n2 = texture(noise0,UV*0.3+vec2(TIME*0.3,TIME)*0.3).r;
	ALBEDO = Color*n0*n1*n2*c0*Emit;
}
