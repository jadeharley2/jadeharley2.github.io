// NOTE: Shader automatically converted from Godot Engine 4.7.3.rc's CanvasItemMaterial.

shader_type canvas_item;
render_mode blend_mix;

varying vec4 vertex_color;
void vertex() {
  vertex_color = COLOR;
}
void fragment() {
    COLOR = texture(TEXTURE, SCREEN_UV*TEXTURE_PIXEL_SIZE/SCREEN_PIXEL_SIZE )*vertex_color;
}