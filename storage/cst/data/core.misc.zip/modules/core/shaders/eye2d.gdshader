shader_type spatial;


uniform sampler2D eye : source_color, filter_nearest, repeat_disable, hint_default_transparent;
uniform vec3 color_eye : source_color = vec3(1.0,1.0,1.0);

uniform sampler2D eyeshade : source_color, filter_nearest, repeat_disable, hint_default_transparent;
uniform vec4 color_eyeshade : source_color = vec4(1.0,1.0,1.0,1.0);

uniform sampler2D eyelash : source_color, filter_nearest, repeat_disable, hint_default_transparent;
uniform vec3 color_eyelash : source_color = vec3(1.0,1.0,1.0);

uniform sampler2D eyebrow : source_color, filter_nearest, repeat_disable, hint_default_transparent;
uniform vec4 color_eyebrow : source_color = vec4(1.0,1.0,1.0,1.0);

uniform sampler2D eye_mask : source_color, hint_default_transparent, filter_nearest, repeat_disable;
uniform vec3 color_eye_mask : source_color = vec3(1.0,1.0,1.0);

uniform sampler2D eye_overlay : source_color, hint_default_transparent, filter_nearest, repeat_disable;
uniform vec3 color_eye_overlay : source_color = vec3(1.0,1.0,1.0);

uniform sampler2D iris : source_color, hint_default_transparent, filter_nearest, repeat_disable;
uniform vec3 color_iris : source_color = vec3(0.0,1.0,0.0);

uniform sampler2D iris_glow : source_color, hint_default_transparent, filter_nearest, repeat_disable;
uniform vec3 color_iris_glow : source_color = vec3(0.0,1.0,0.0);
uniform float glow_power = 0;

uniform sampler2D hole : source_color, hint_default_transparent, filter_nearest, repeat_disable;
uniform vec3 color_hole : source_color = vec3(0.0,0.0,0.0);

uniform vec2 iris_offset;
uniform vec2 iris_scale = vec2(1.0,1.0);
uniform vec2 eye_pixel_size = vec2(32.0,32.0);
uniform float eyel_lr: hint_range(-1.0, 1.0, 0.01) = 0;
uniform float eyel_ud: hint_range(-1.0, 1.0, 0.01) = 0;
uniform float clip_tr : hint_range(0.0, 1.0, 0.01) = 0.1;


uniform vec2 uv_shift = vec2(0.0,0.0);

void fragment() {
	vec2 uv = UV + uv_shift;
	float maskv = texture(eye_mask,uv).a;
	vec4 col = vec4(0,0,0,0);
	vec2 szdf =  eye_pixel_size / vec2(textureSize(iris,0));
	vec2 resized = (uv* szdf+iris_offset-vec2(0.5,0.5)) *iris_scale+vec2(0.5,0.5);

	vec2 IRISUV =resized +vec2(eyel_lr,eyel_ud);

	vec4 ciris = texture(iris,IRISUV);
	vec4 chole = texture(hole,IRISUV);
	//ALBEDO = ciris.rgb;

	vec4 ceye = texture(eye,uv  );
	vec4 ceyeshade = texture(eyeshade,uv  );
	vec4 ceyelash = texture(eyelash,uv  );
	vec4 ceyebrow = texture(eyebrow,uv  );


	vec4 ceyeov = texture(eye_overlay,uv  );

	col.rgb = mix(col.rgb, ceye.rgb*color_eye,ceye.a);
	col.rgb = mix(col.rgb, ceyeshade.rgb*color_eyeshade.rgb,ceyeshade.a*color_eyeshade.a);


	col.rgb = mix(col.rgb, maskv*color_eye_mask, maskv);
	col.rgb = mix(col.rgb, ciris.rgb*color_iris,ciris.a*maskv);
	col.rgb = mix(col.rgb, chole.rgb*color_hole,chole.a*maskv);

	col.rgb = mix(col.rgb, ceyelash.rgb*color_eyelash,ceyelash.a);
	col.rgb = mix(col.rgb, ceyebrow.rgb*color_eyebrow.rgb,ceyebrow.a*color_eyebrow.a);

	float eye_alpha = maskv
		+ ceye.a
		+ ceyeshade.a*color_eyeshade.a
		+ ceyelash.a
		+ ceyebrow.a*color_eyebrow.a;


	col.rgb = mix(col.rgb, ceyeov.rgb,ceyeov.a);
	col.a = max(eye_alpha,maskv);
	if(col.a<clip_tr){
		discard;
	}

	vec4 emit_tex =texture(iris_glow,IRISUV);
	vec3 emit = emit_tex.rgb * emit_tex.a * max(0,maskv-ceyelash.a) * color_iris_glow * glow_power;

	ALBEDO = col.rgb;
	EMISSION = emit;

}
