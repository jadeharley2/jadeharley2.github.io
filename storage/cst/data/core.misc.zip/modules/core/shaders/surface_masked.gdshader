shader_type spatial;

render_mode depth_prepass_alpha , diffuse_burley, specular_schlick_ggx;

uniform vec4 tintR : source_color = vec4(1,0,0,1) ;
uniform vec4 tintG : source_color = vec4(0,1,0,1) ;
uniform vec4 tintB : source_color = vec4(0,0,1,1) ;
uniform vec4 tintA : source_color = vec4(0,0,0,1) ;
uniform sampler2D mask_texture : source_color, filter_nearest;
uniform sampler2D emit_texture : source_color, filter_nearest, hint_default_black;
uniform sampler2D texture_normal : hint_normal, filter_nearest;
uniform sampler2D texture_mask : hint_default_black, filter_nearest;

uniform sampler2D texture_noise : hint_default_white, filter_nearest;

uniform vec4 emission : source_color = vec4(1,1,1,1) ;

uniform float specular: hint_range(0,1) = 0.5;
uniform float metallic: hint_range(-1,1) = 0.0;
uniform float roughness : hint_range(-1,1) = 1.0;
uniform float alpha_scissor_threshold : hint_range(0.0, 1.0) = 0.5;

uniform float damage : hint_range(0,2) = 0.0;

global uniform vec4 clip_plane0;



varying vec3 world_pos;
void vertex()
{
	world_pos = ( MODEL_MATRIX * vec4( VERTEX, 1.0 ) ).xyz;
}

void fragment() {
	vec4 VERTEX_WORLD = INV_VIEW_MATRIX * vec4(VERTEX, 1.0);
	if(dot(VERTEX_WORLD.xyz,clip_plane0.xyz)<clip_plane0.w){
		discard;
	}
	vec2 base_uv = UV;

	vec4 noise_tex = texture(texture_noise, floor(base_uv*256.0)/256.0*4.0);// mix(nt_x,nt_y,world_norm.y);
	if(noise_tex.r<damage-0.8){
		discard;
	}
	
	vec4 mask_tex = texture(mask_texture, base_uv);

	
	vec4 color0 =//mix(tintA ,
		mix(mix(mix(mix(vec4(0,0,0,1),tintR,mask_tex.r),tintB,mask_tex.b),tintG,mask_tex.g),tintA,1.0-mask_tex.a);
		//mask_tex.g * tintG +
		//mask_tex.b * tintB +
		//(1.0-mask_tex.a) * tintA;//#, mask_tex.a);


	float vis_damage = clamp(pow(noise_tex.r-damage+0.6,0.9)*2.0,0.0,1.0);
	ALBEDO =  color0.rgb * vis_damage;//hsv2rgb(color0);
	vec4 mask = texture(texture_mask,base_uv);
	ROUGHNESS = mask.r + roughness;// * roughness_tex
	METALLIC = mask.b  + metallic;// * metallic_tex;
	SPECULAR = specular;

	NORMAL_MAP = texture(texture_normal,base_uv).rgb;
	EMISSION = texture(emit_texture,base_uv).rgb*10.0*emission.rgb;

	ALPHA = color0.a;
	ALPHA_SCISSOR_THRESHOLD = alpha_scissor_threshold;
}
