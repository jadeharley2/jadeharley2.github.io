
// https://www.shadertoy.com/view/msXXDS

/*
 * Copyright (c) 2023 Fernando García Liñán
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

const float INV_PI = 0.31830988618379067154;
const float INV_4PI = 0.25 * INV_PI;
const float PHASE_ISOTROPIC = INV_4PI;
const float RAYLEIGH_PHASE_SCALE = (3.0 / 16.0) * INV_PI;
const float g = 0.8;
const float gg = g*g;

// Ray marching steps. More steps mean better accuracy but worse performance
const int IN_SCATTERING_STEPS = 30;

uniform vec3 sun_direction = vec3(1,0,0);
uniform vec3 camera_pos = vec3(0,0,0);

uniform sampler2D transmittance_lut;

// All parameters that depend on wavelength (vec4) are sampled at
// 630, 560, 490, 430 nanometers

uniform float EARTH_RADIUS = 6371.0; // km
uniform float ATMOSPHERE_THICKNESS = 100.0; // km
#define ATMOSPHERE_RADIUS (EARTH_RADIUS + ATMOSPHERE_THICKNESS)
uniform float EYE_ALTITUDE          = 0.5;
#define EYE_DISTANCE_TO_EARTH_CENTER (EARTH_RADIUS + EYE_ALTITUDE)
uniform vec4  GROUND_ALBEDO : source_color= vec4(0.3,0.3,0.3,1.0);

// Extraterrestial Solar Irradiance Spectra, units W * m^-2 * nm^-1
// https://www.nrel.gov/grid/solar-resource/spectra.html
uniform vec4 sun_spectral_irradiance = vec4(1.679, 1.828, 1.986, 1.307);
// Rayleigh scattering coefficient at sea level, units km^-1
// "Rayleigh-scattering calculations for the terrestrial atmosphere"
// by Anthony Bucholtz (1995).
uniform vec4 molecular_scattering_coefficient_base = vec4(6.605e-3, 1.067e-2, 1.842e-2, 3.156e-2);
// Ozone absorption cross section, units m^2 / molecules
// "High spectral resolution ozone absorption cross-sections"
// by V. Gorshelev et al. (2014).
const vec4 ozone_absorption_cross_section = vec4(3.472e-21, 3.914e-21, 1.349e-21, 11.03e-23) * 1e-4f;

// Mean ozone concentration in Dobson for each month of the year.
uniform float ozone_mean_monthly_dobson = 350.0;

/*
 * This model for aerosols and their corresponding parameters come from
 * "A Physically-Based Spatio-Temporal Sky Model"
 * by Guimera et al. (2018).
 */
//const highp vec4 aerosol_absorption_cross_section = vec4(6.3312e-19, 7.5567e-19, 9.2627e-19, 1.0391e-18);
//const highp vec4 aerosol_scattering_cross_section = vec4(4.6539e-26, 2.721e-26, 4.1104e-26, 5.6249e-26);
//const highp float aerosol_base_density = 2.584e17;
//uniform float aerosol_background_density = 2e6;

const highp vec4 aerosol_absorption_cross_section = vec4(6.3312e-10, 7.5567e-10, 9.2627e-10, 1.0391e-10);
const highp vec4 aerosol_scattering_cross_section = vec4(2.6539e-10, 2.721e-10, 4.1104e-10, 5.6249e-10);
const highp float aerosol_base_density = 2.584e8;
uniform float aerosol_background_density = 2e3;
uniform float aerosol_height_scale =1.1;// 0.73;
#define aerosol_background_divided_by_base_density (aerosol_background_density / aerosol_base_density)

//const float aerosol_background_divided_by_base_density = aerosol_background_density / aerosol_base_density;

//-----------------------------------------------------------------------------

/*
 * Returns the distance between ro and the first intersection with the sphere
 * or -1.0 if there is no intersection. The sphere's origin is (0,0,0).
 * -1.0 is also returned if the ray is pointing away from the sphere.
 */
float ray_sphere_intersection(vec3 ro, vec3 rd, float radius)
{
    float b = dot(ro, rd);
    float c = dot(ro, ro) - radius*radius;
    if (c > 0.0 && b > 0.0) return -1.0;
    float d = b*b - c;
    if (d < 0.0) return -1.0;
    if (d > b*b) return (-b+sqrt(d));
    return (-b-sqrt(d));
}

/*
 * Rayleigh phase function.
 */
float molecular_phase_function(float cos_theta)
{
    return RAYLEIGH_PHASE_SCALE * (1.0 + cos_theta*cos_theta);
}

/*
 * Henyey-Greenstrein phase function.
 */
float aerosol_phase_function(float cos_theta)
{
    float den = 1.0 + gg + 2.0 * g * cos_theta;
    return INV_4PI * (1.0 - gg) / (den * sqrt(den));
}

/*
 * Return the molecular volume scattering coefficient (km^-1) for a given altitude
 * in kilometers.
 */
vec4 get_molecular_scattering_coefficient(float h)
{
    return molecular_scattering_coefficient_base * exp(-0.07771971 * pow(h, 1.16364243));
}

vec4 transmittance_from_lut(float cos_theta, float normalized_altitude)
{
    float u = clamp(cos_theta * 0.5 + 0.5, 0.0, 1.0);
    float v = clamp(normalized_altitude, 0.0, 1.0);
    return texture(transmittance_lut, vec2(u, v));
}

vec4 get_multiple_scattering( float cos_theta, float normalized_height, float d)
{
    // Solid angle subtended by the planet from a point at d distance
    // from the planet center.
    float omega = 2.0 * PI * (1.0 - sqrt(d*d - EARTH_RADIUS*EARTH_RADIUS) / d);

    vec4 T_to_ground = transmittance_from_lut( cos_theta, 0.0);

    vec4 T_ground_to_sample =
        transmittance_from_lut( 1.0, 0.0) /
        transmittance_from_lut( 1.0, normalized_height);

    // 2nd order scattering from the ground
    vec4 L_ground = PHASE_ISOTROPIC * omega * (GROUND_ALBEDO / PI) * T_to_ground * T_ground_to_sample * cos_theta;

    // Fit of Earth's multiple scattering coming from other points in the atmosphere
    vec4 L_ms = 0.02 * vec4(0.217, 0.347, 0.594, 1.0) * (1.0 / (1.0 + 5.0 * exp(-17.92 * cos_theta)));

    return L_ms + L_ground;

}

/*
 * Return the molecular volume absorption coefficient (km^-1) for a given altitude
 * in kilometers.
 */
highp vec4 get_molecular_absorption_coefficient(float h)
{
    h += 1e-4; // Avoid division by 0
    float t = log(h) - 3.22261;
    highp float density = 3.78547397e20 * (1.0 / h) * exp(-t * t * 5.55555555);
    return ozone_absorption_cross_section * ozone_mean_monthly_dobson * density;
}

highp float get_aerosol_density(float h)
{ 
    return aerosol_base_density * (exp(-h / aerosol_height_scale)
         + aerosol_background_divided_by_base_density);
}

/*
 * Get the collision coefficients (scattering and absorption) of the
 * atmospheric medium for a given point at an altitude h.
 */
void get_atmosphere_collision_coefficients(in float h,
                                           out highp vec4 aerosol_absorption,
                                           out highp vec4 aerosol_scattering,
                                           out highp vec4 molecular_absorption,
                                           out highp vec4 molecular_scattering,
                                           out vec4 extinction)
{
    h = max(h, 0.0); // In case height is negative
    highp float aerosol_density = get_aerosol_density(h);
    aerosol_absorption = aerosol_absorption_cross_section * aerosol_density;
    aerosol_scattering = aerosol_scattering_cross_section * aerosol_density;
    molecular_absorption = get_molecular_absorption_coefficient(h);
    molecular_scattering = get_molecular_scattering_coefficient(h);

    extinction = aerosol_absorption + aerosol_scattering + molecular_absorption + molecular_scattering;
}

//-----------------------------------------------------------------------------
// Spectral rendering stuff 
const mat4 M = mat4(
    vec4(137.672389239975, -8.632904716299537, -1.7181567391931372, 1.0),
    vec4(32.549094028629234, 91.29801417199785, -12.005406444382531, 1.0),
    vec4(-38.91428392614275, 34.31665471469816, 29.89044807197628, 1.0),
    vec4(8.572844237945445, -11.103384660054624, 117.47585277566478, 1.0)
);

vec3 linear_srgb_from_spectral_samples(vec4 L)
{
    return (M * L).xyz;
} 

vec4 compute_inscattering(vec3 ray_origin, vec3 ray_dir, float t_d, out vec4 transmittance)
{
    vec3 sun_dir = sun_direction.xyz; 
    float cos_theta = dot(-ray_dir, sun_dir);
	
	
    float distance_to_earth_center2 = length(ray_origin);
    //vec3 zenith_dir2 = ray_origin / distance_to_earth_center2;

    float molecular_phase = molecular_phase_function(cos_theta);
    float aerosol_phase = aerosol_phase_function(cos_theta)*clamp(t_d*0.01,0,1);//*clamp( dot(ray_dir, zenith_dir2)*100.0,0,1);
	
    float dt = t_d / float(IN_SCATTERING_STEPS);

    vec4 L_inscattering = vec4(0.0);
    transmittance = vec4(1.0);

    for (int i = 0; i < IN_SCATTERING_STEPS; ++i) {
        float t = (float(i) + 0.5) * dt;
        vec3 x_t = ray_origin + ray_dir * t;

        float distance_to_earth_center = length(x_t);
        vec3 zenith_dir = x_t / distance_to_earth_center;
        float altitude = distance_to_earth_center - EARTH_RADIUS;
        float normalized_altitude = altitude / ATMOSPHERE_THICKNESS;

        float sample_cos_theta = 0.99* dot(zenith_dir, sun_dir);

        highp vec4 aerosol_absorption, aerosol_scattering;
        highp vec4 molecular_absorption, molecular_scattering;
        highp vec4 extinction;
        get_atmosphere_collision_coefficients(
            altitude,
            aerosol_absorption, aerosol_scattering,
            molecular_absorption, molecular_scattering,
            extinction);
		//aerosol_scattering =vec4(1)* 0.0001;

        vec4 transmittance_to_sun = transmittance_from_lut(   sample_cos_theta, normalized_altitude);

        vec4 ms = get_multiple_scattering(
             sample_cos_theta, normalized_altitude,
            distance_to_earth_center);

        vec4 S = sun_spectral_irradiance *
            (molecular_scattering * (molecular_phase * transmittance_to_sun + ms) +
             aerosol_scattering * (aerosol_phase   * transmittance_to_sun + ms));
 
		//S = aerosol_scattering *sun_spectral_irradiance * 0.1 * aerosol_phase;
		
        vec4 step_transmittance = exp(-dt * extinction);

        // Energy-conserving analytical integration
        // "Physically Based Sky, Atmosphere and Cloud Rendering in Frostbite"
        // by Sébastien Hillaire
        vec4 S_int = (S - S * step_transmittance) / max(extinction, 1e-7);
        L_inscattering += transmittance * S_int;
        transmittance *= step_transmittance; 
    } 
    //float altitude2 = distance_to_earth_center2 - EARTH_RADIUS;
    //float normalized_altitude2 = altitude2 / ATMOSPHERE_THICKNESS;
	 
    return L_inscattering;
}


vec4 atmosphere(vec2 uv, vec3 ray_origin, vec3 ray_dir, out vec4 transmittance)
{
    float azimuth = 2.0 * PI * uv.x;

    // Apply a non-linear transformation to the elevation to dedicate more
    // texels to the horizon, where having more detail matters.
    //float l = uv.y * 2.0 - 1.0;
    //float elev = l*l * sign(l) * PI * 0.5; // [-pi/2, pi/2]


    float atmos_dist  = ray_sphere_intersection(ray_origin, ray_dir, ATMOSPHERE_RADIUS);
    float ground_dist = ray_sphere_intersection(ray_origin, ray_dir, EARTH_RADIUS);
    float t_d;
	
    if (EYE_ALTITUDE < ATMOSPHERE_THICKNESS) { 
	    if (ground_dist < 1.0) {
	        // No ground collision, use the distance to the outer atmosphere
	        t_d = atmos_dist;
	    } else {
	        // We have a collision with the ground, use the distance to it
	        t_d = ground_dist;
	    } 
	}else{ 
        // Move the ray origin to the atmosphere intersection
        ray_origin = ray_origin + ray_dir * (atmos_dist + 1e-1);
        if (ground_dist < 0.0) {
            // No collision with the ground, so the ray is exiting through
            // the atmosphere.
            float second_atmos_dist = ray_sphere_intersection(
                ray_origin, ray_dir, ATMOSPHERE_RADIUS);
            t_d = second_atmos_dist;
        } else {
            t_d = ground_dist - atmos_dist;
        }
	}
	

    return compute_inscattering(ray_origin, ray_dir, t_d, transmittance); 
	
}