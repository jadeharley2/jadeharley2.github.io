
shader_type spatial;
render_mode unshaded, blend_add; 

#include "inc_atmosphere.gdshaderinc"


varying vec3 wpos;

void vertex() 
{
	wpos = VERTEX; 
}
void fragment() 
{ 
	vec2 uv = UV;
    vec3 ray_origin = camera_pos; 
    vec3 ray_dir = normalize(wpos-camera_pos/(EARTH_RADIUS*2.05 )); 
	vec4 transmittance;
	vec4 L = atmosphere(uv,ray_origin,ray_dir,transmittance);
	
	//ALBEDO = linear_srgb_from_spectral_samples(L)*0.02;//*10.0;  
	ALBEDO = L.xyz*10.0;//*10.
	//ALBEDO = vec3(ground_dist,atmos_dist*0.001,0)*0.1;
}