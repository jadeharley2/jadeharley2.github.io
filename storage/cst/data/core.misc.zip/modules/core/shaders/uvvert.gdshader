
shader_type spatial;
render_mode world_vertex_coords;


uniform sampler2D albedo_texture : source_color, filter_nearest, repeat_disable;

void vertex(){
	VERTEX = vec3(UV,0);
}
void fragment() {
	vec4 albedo_tex = texture(albedo_texture, UV);
	EMISSION = albedo_tex.rgb;
}
