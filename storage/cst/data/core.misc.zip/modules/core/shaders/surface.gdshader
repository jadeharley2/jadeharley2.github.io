shader_type spatial;

render_mode depth_prepass_alpha , diffuse_burley, specular_schlick_ggx;

uniform vec4 albedo : source_color = vec4(1,1,1,1) ;
uniform sampler2D albedo_texture : source_color, filter_nearest;
uniform vec4 emission : source_color = vec4(1,1,1,1) ;
uniform sampler2D emit_texture : source_color, filter_nearest, hint_default_black;
uniform sampler2D albedo2_texture : source_color, filter_nearest;
uniform sampler2D texture_normal : hint_normal, filter_nearest;
uniform float specular: hint_range(0,1) = 0.5;
uniform float metallic: hint_range(-1,1) = 0.0;
uniform float roughness : hint_range(-1,1) = 1.0;
uniform float alpha_scissor_threshold : hint_range(0.0, 1.0);
uniform sampler2D texture_mask : hint_default_white, filter_nearest;
uniform vec2 texture_uv_scale = vec2(1,1);

uniform vec2 noise_uv_scale = vec2(10,10);
uniform sampler2D noise_texture : hint_default_white;
uniform float noise_shift_mul : hint_range(-1.0, 1.0) = 0.1;
uniform sampler2D noise_texture2 : hint_default_black;

global uniform vec4 clip_plane0;

vec3 rgb2hsv(vec3 c) {
    vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));

    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}

vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}


varying vec3 world_pos;
void vertex()
{
	world_pos = ( MODEL_MATRIX * vec4( VERTEX, 1.0 ) ).xyz;
	//vec4 noise_tex = texture(noise_texture2,world_pos.xz*noise_uv_scale);
	//world_pos+=vec3(noise_tex.x-0.5,0,0);
	//VERTEX = ( inverse(MODEL_MATRIX) * vec4( world_pos, 1.0 ) ).xyz;
}

void fragment() {
	vec4 VERTEX_WORLD = INV_VIEW_MATRIX * vec4(VERTEX, 1.0);
	if(dot(VERTEX_WORLD.xyz,clip_plane0.xyz)<clip_plane0.w){
		discard;
	}

	vec2 base_uv = UV*texture_uv_scale;
	vec4 albedo_tex = texture(albedo_texture, base_uv);
	//vec4 albedo2_tex = texture(albedo2_texture, base_uv);
	vec4 noise_tex = texture(noise_texture,world_pos.xz*noise_uv_scale);

	vec4 color0 = albedo_tex;// mix(albedo_tex,albedo2_tex,noise_tex);//rgb2hsv( albedo_tex.rgb);
	//color0.y =color0.y+(noise_tex.r-0.5)*noise_shift_mul;
	vec3 bc = floor(COLOR.rgb*8.0)/8.0;
	ALBEDO =  albedo.rgb *color0.rgb * bc;//hsv2rgb(color0);
	vec4 mask = texture(texture_mask,base_uv);
	ROUGHNESS = mask.r + roughness;// * roughness_tex
	METALLIC = mask.b  + metallic;// * metallic_tex;
	SPECULAR = specular;

	vec3 nrmvec = (texture(texture_normal,base_uv).rgb-0.5)*2.0;
	nrmvec *=vec3(2,2,1);
	vec3 nrmclr = nrmvec*0.5+0.5;
	NORMAL_MAP = nrmclr;
	EMISSION = texture(emit_texture,base_uv).rgb*10.0*emission.rgb * bc;
	//vec3 transmission_tex = texture(texture_transmission, base_uv).rgb;
	//TRANSMISSION = (transmission.rgb + transmission_tex);
	ALPHA = albedo.a * albedo_tex.a;
	ALPHA_SCISSOR_THRESHOLD = alpha_scissor_threshold;
}
